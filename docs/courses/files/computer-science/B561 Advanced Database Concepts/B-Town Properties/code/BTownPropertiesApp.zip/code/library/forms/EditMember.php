<?php

/**
 * Description of Member
 *
 * @author enriqueareyan & mercerjd
 */
class library_forms_EditMember extends library_forms_Member {
    public function init() {
        parent::init('Update', true);
    }    
}
