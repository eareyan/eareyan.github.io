<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BTownException
 *
 * @author enriqueareyan
 */
class library_classes_BTownException extends Exception {
    //put your code here
}