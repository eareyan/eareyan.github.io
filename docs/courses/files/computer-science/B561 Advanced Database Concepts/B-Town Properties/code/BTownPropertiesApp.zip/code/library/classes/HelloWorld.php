<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of HelloWorld
 *
 * @author mercerjd
 */
class library_classes_HelloWorld {
    //put your code here
    
    function __toString() {
        return "Hello World";
    }
}

?>
