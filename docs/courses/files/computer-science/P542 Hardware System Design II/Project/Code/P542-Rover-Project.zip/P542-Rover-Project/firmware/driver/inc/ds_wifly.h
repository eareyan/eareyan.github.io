
#ifndef __ds_wifly__
#define __ds_wifly__

void ds_wifly_init(void);
void ds_wifly_send(const char *cmd);
void ds_wifly_recv(char *rcvbuf, unsigned len);

// TODO - make consistent.
char* get_line_from_wifly(void);

#endif



