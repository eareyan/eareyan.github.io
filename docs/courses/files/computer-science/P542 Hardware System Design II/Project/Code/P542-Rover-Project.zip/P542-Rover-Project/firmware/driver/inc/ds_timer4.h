#include <stm32f30x.h>

void ds_timer4_init(void); 
void ds_hightime_oc1_uS(uint32_t);
extern uint32_t pulse_width;