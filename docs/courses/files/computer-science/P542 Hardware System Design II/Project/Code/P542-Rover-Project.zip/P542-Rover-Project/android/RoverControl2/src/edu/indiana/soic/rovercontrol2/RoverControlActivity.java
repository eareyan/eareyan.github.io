package edu.indiana.soic.rovercontrol2;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.util.Log;

import edu.indiana.soic.rovercontrol2.RoverControl;

import java.net.Socket;

public class RoverControlActivity extends Activity {

	private static String ACTIVITY = "BotCtl::Control";
	private static Socket sock     = null;
	private static int    seq      = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rover_control);
		sock = ConnectionManager.tryConnect();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.rover_control, menu);
		return true;
	}

	public void onClickMoveForward(View view) {
		Log.d(ACTIVITY, "move forward");
		RoverControl.goForward(sock, seq);
	}
	
	public void onClickMoveRight(View view) {
		Log.d(ACTIVITY, "move right");
		RoverControl.turnRight(sock, seq);
	}
	
	public void onClickMoveLeft(View view) {
		Log.d(ACTIVITY, "move left");
		RoverControl.turnLeft(sock, seq);
	}
	
	public void onClickMoveBackward(View view) {
		Log.d(ACTIVITY, "move backward");
		RoverControl.goBackward(sock, seq);
	}
	
	public void onClickMoveStop(View view) {
		Log.d(ACTIVITY, "stop");
		RoverControl.stopRover(sock, seq);
	}
	
	public void onClickMoveClockwise(View view) {
		Log.d(ACTIVITY, "clockwise");
		RoverControl.turnClockwise(sock, seq);
	}
	
	public void onClickMoveCounterClockwise(View view){
		Log.d(ACTIVITY, "counter-clockwise");
		RoverControl.turnCounterClockwise(sock, seq);
	}
}
