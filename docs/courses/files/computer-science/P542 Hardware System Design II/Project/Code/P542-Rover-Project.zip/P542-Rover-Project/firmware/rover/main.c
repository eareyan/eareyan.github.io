/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */
/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers
#include <ds_userbutton.h>     // Pull in include file for the local drivers
#include <ds_systick.h> // Pull in include file for the local drivers
#include <ds_led.h>
#include <ds_uart.h>
#include <ds_rtc.h>
#include <ds_i2c.h>
#include <stdio.h>
#include <handle_user_input.h>
#include <ds_wifly.h>
#include <string.h>
#include <ds_delay.h>
#include <ds_timer4.h>


enum {FORWARD,REVERSE};
void right_track(int dir, int enable) {
  if (enable) {
    ds_led_on(10);
    ds_led_on(11);
    if (dir==FORWARD) {
      ds_led_on(14);  // Right Front Forward 
      ds_led_off(15); // Right Rear Forward
    }
    else {
      ds_led_off(14);  // Right Front Reverse 
      ds_led_on(15); // Right Rear Reverse
    }
  }    
  else {
      ds_led_off(10);
      ds_led_off(11);
  }
}

void left_track(int dir, int enable) {
  if (enable) {
    ds_led_on(8);
    ds_led_on(9);
    if (dir==FORWARD) {
      ds_led_on(12);  // Right Front Forward 
      ds_led_off(13); // Right Rear Forward
    }
    else {
      ds_led_off(12);  // Right Front Reverse 
      ds_led_on(13); // Right Rear Reverse
    }
  }    
  else {
      ds_led_off(8);
      ds_led_off(9);
  }
}

int control_cart(char * message){

	if(strcmp(message, "s") == 0){
		left_track(FORWARD,0);
		right_track(FORWARD,0);	
		return 1;	
	}
	if(strcmp(message, "gf") == 0){
		left_track(FORWARD,1);
		right_track(FORWARD,1);
		return 1;
	}
	if(strcmp(message, "gb") == 0){
		left_track(REVERSE,1);
		right_track(REVERSE,1);
		return 1;
	}
	if(strcmp(message, "lf") == 0){
		left_track(FORWARD,1);
		right_track(FORWARD,0);			
		return 1;
	}
	if(strcmp(message, "rf") == 0){
		left_track(FORWARD,0);
		right_track(FORWARD,1);			
		return 1;
	}
	if(strcmp(message, "lb") == 0){
		left_track(REVERSE,1);
		right_track(REVERSE,0);			
		return 1;
	}
	if(strcmp(message, "rb") == 0){
		left_track(REVERSE,0);
		right_track(REVERSE,1);			
		return 1;
	}
	if(strcmp(message, "c") == 0){
		left_track(FORWARD,1);
		right_track(REVERSE,1);			
		return 1;
	}
	if(strcmp(message, "cc") == 0){
		left_track(REVERSE,1);
		right_track(FORWARD,1);			
		return 1;
	}
	if(strcmp(message, "e") == 0){
		putstring_wifly("$$$");
		putstring_wifly("close");
		putstring_wifly("exit");
	}
	return 0;
}

int main(void) { 
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	//Initialize all leds
	ds_led_init();
	//Initialize user button
	ds_userbutton_init();
	//Init systick
	ds_systick_init();
        //Initialize uart
	uart_init();
	//Initialize clock
	ds_rtc_init();
	//Wifly Init
	ds_wifly_init();
	//Initialize delay
	ds_delay_init();
	//Initialize Timer 4 (for Sonar)
	ds_timer4_init();


	char * client_data;
	int i=0;
	ds_hightime_oc1_uS(1000);
	while(1){		

		/* GET LINE FROM WIFLY (non-blocking) */
		client_data = non_blocking_get_line_from_wifly();
		//client_data = non_blocking_get_line_from_user(); //this one is from USART
		if(client_data != 0){ 					// If there is an actual message
			printf("%d: client_data = %s\n",i,client_data); //print message
			if(!control_cart(client_data)){ 		// send message to control
				printf("\n unknown message \n"); 	//the message does not follow our protocol
			}
		}
		/* SONAR CONTROL*/
		if(pulse_width <= 900 ){ // If we are too close, send an stop message
			control_cart("s");
			printf("%d Obstacle nearby: %d\n",i,pulse_width);
		}
		/*Keeping track of how many loops so far, just for debbuging */
		//i++;
	}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif
