#include <stm32f30x.h>
#define SONAR_TRIGGER_LOW()   GPIO_ResetBits(GPIOC, GPIO_Pin_7);
#define SONAR_TRIGGER_HIGH()  GPIO_SetBits(GPIOC, GPIO_Pin_7);

void ds_sonar_init(void);
void send_pulse(void);
void measure_pulse(void);

void setup_timer(void);

