# Simple twisted-based server to proxy client requests to rover and
# back.
#
# TODO: keep a connection to rover; reconnect on failure
# TODO: forward commands to rover
# TODO: relay responses from the rover back to the client.

from twisted.internet import reactor
from twisted.protocols import basic
from twisted.application import service, internet
from twisted.protocols.basic import LineReceiver
from twisted.internet.protocol import ClientFactory

import json

class RoverControlServer(LineReceiver):
    def __init__(self):
        LineReceiver.setRawMode(self)
        # LineReceiver.setLineMode(self)
        
    def connectionMade(self):
        print "Got new client!"
        self.factory.clients.append(self)

    def connectionLost(self, reason):
        print "Lost a client!"
        self.factory.clients.remove(self)

    def rawDataReceived(self, data):
        print "received", repr(data)
        cmd = json.loads(data)
        print "cmd:", cmd
        print "command: ", cmd[u'command']

    def lineReceived(self, line):
        print "received", repr(line)
        
        # for c in self.factory.clients:
        #     c.message(line)

    def message(self, message):
        self.transport.write(message + '\n')

class RoverControlServerFactory(ClientFactory):
    protocol = RoverControlServer

    def clientConnectionFailed(self, connector, reason):
        print 'connection failed:', reason.getErrorMessage()
        reactor.stop()

    def clientConnectionLost(self, connector, reason):
        print 'connection lost:', reason.getErrorMessage()
        reactor.stop()

def main():
    factory = RoverControlServerFactory()
    factory.clients= []
    reactor.listenTCP(9000, factory)
    reactor.run()

if __name__ == '__main__':
    main()

