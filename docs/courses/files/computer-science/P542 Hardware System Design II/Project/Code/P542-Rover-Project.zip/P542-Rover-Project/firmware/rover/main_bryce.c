/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */
/* Code: */
#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers
#include <ds_userbutton.h>
#include <ds_uart.h>
//#include <ds_gyro.h>
//#include <ds_i2c.h>
//#include <ds_accel.h>
//#include <ds_mag.h> 
#include <ds_systick.h>
#include <ds_rtc.h>
//#include <schedule.h> 
#include <ds_delay.h>
//#include <ds_wifibase.h>
//#include <ds_timer2.h>
//#include <ds_dac.h>
//#include <ds_a2d.h>
//#include <ds_timer4.h>
#include <stdio.h>
#include <stdlib.h>

void system_init(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  ds_led_init();
  ds_userbutton_init();
  uart_init();
  // ds_gyro_init();
  // ds_i2c1_init();
  // ds_accel_init();
  // ds_mag_init();
  ds_systick_init();
  ds_rtc_init();
  ds_delay_init();
//  ds_timer2_init(); 
//  ds_dac_init();
//  ds_a2d_init();
//  ds_timer4_init();
}

// Led 0 Left Rear PWM
// Led 1 Left Front PWM
// Led 2 Right Front PWM
// Led 3 Right Rear PWM
// Led 4 Left Rear Dir (1=Forward)
// Led 5 Left Front Dir (0 = Forward)
// Led 6 Right Front Dir (1=Forward)
// Led 7 Right Read Dir (0=Forward)

enum {FORWARD,REVERSE};
void right_track(int dir, int enable) {
  if (enable) {
    ds_led_on(2);
    ds_led_on(3);
    if (dir==FORWARD) {
      ds_led_on(6);  // Right Front Forward 
      ds_led_off(7); // Right Rear Forward
    }
    else {
      ds_led_off(6);  // Right Front Reverse 
      ds_led_on(7); // Right Rear Reverse
    }
  }    
  else {
      ds_led_off(2);
      ds_led_off(3);
  }
}

void left_track(int dir, int enable) {
  if (enable) {
    ds_led_on(0);
    ds_led_on(1);
    if (dir==FORWARD) {
      ds_led_on(4);  // Right Front Forward 
      ds_led_off(5); // Right Rear Forward
    }
    else {
      ds_led_off(4);  // Right Front Reverse 
      ds_led_on(5); // Right Rear Reverse
    }
  }    
  else {
      ds_led_off(0);
      ds_led_off(1);
  }
}


int main(void) { 
  system_init();
  printf("Rover Example\n");
  ds_led_all_off();
  ds_led_on(3);
  right_track(FORWARD,ENABLE);
  left_track(FORWARD,ENABLE);

  while(1);
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif
