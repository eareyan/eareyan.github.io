#include <handle_file_operations.h>

void die (		/* Stop with dying message */
	FRESULT rc	/* FatFs return value */
)
{
	printf("Failed with rc=%u.\n", rc);
	for (;;) ;
}

void file_init(void){
	f_mount(0, &Fatfs);		/* Register volume work area (never fails) */
}

void append_to_file(char * filename , char * data){
	rc = f_open(&Fil, filename, FA_OPEN_ALWAYS | FA_WRITE);
	if (rc) die(rc);
	rc = f_lseek(&Fil, f_size(&Fil));
	if (rc) die(rc);
	rc = f_write(&Fil, data, strlen(data), &bw);
	if (rc) die(rc);
	rc = f_close(&Fil);
	if (rc) die(rc);
}
void delete_file_contents(char * filename){

	rc = f_open(&Fil, filename, FA_CREATE_ALWAYS);
	if (rc) die(rc);
	rc = f_close(&Fil);
	if (rc) die(rc);

}
void print_file_contents(char * file){
	printf("\nOpen file %s\n",file);
	rc = f_open(&Fil, file, FA_READ);
	if (rc) die(rc);

	printf("\nContents of the file:\n");
	for (;;) {
		rc = f_read(&Fil, Buff, sizeof Buff, &br);	/* Read a chunk of file */
		if (rc || !br) break;			/* Error or end of file */
		for (i = 0; i < br; i++)		/* Type the data */
			putchar(Buff[i]);
	}
	if (rc) die(rc);

	printf("\nClose the file.\n");
	rc = f_close(&Fil);
	if (rc) die(rc);
}

void print_root_contents(void){

	printf("\nOpen root directory.\n");
	rc = f_opendir(&dir, "");
	if (rc) die(rc);

	printf("\nDirectory listing...\n");
	for (;;) {
		rc = f_readdir(&dir, &fno);		/* Read a directory item */
		if (rc || !fno.fname[0]) break;	/* Error or end of dir */
		if (fno.fattrib & AM_DIR)
			printf("   <dir>  %s\n", fno.fname);
		else
			printf("%8lu  %s\n", fno.fsize, fno.fname);
	}
	if (rc) die(rc);
}
