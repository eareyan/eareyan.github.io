/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 * Keywords: p542-rover-Project Sonar implementation
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of sonar for rover project
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_systick.h> // Pull in include file for the local drivers
#include <ds_uart.h>
#include <ds_userbutton.h>     // Pull in include file for the local drivers
#include <ds_delay.h>
//#include <ds_sonar.h>
#include <ds_led.h>
#include <ds_rtc.h>
#include <ds_i2c.h>
#include <stdio.h>
#include <ds_timer4.h>


int main(void){
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//Init systick
	ds_systick_init();
	//Initialize user button
	ds_userbutton_init();	
	//Initialize leds
	ds_led_init();
	//Initialize uart
	uart_init();
	//Initialize delay
	ds_delay_init();
	//Initialize sonar
	//ds_sonar_init();
	//Initialize Timer 4
	ds_timer4_init();
	
	int flag = 0,i=0;
	printf("begin\n");
	ds_hightime_oc1_uS(1000);
	while (1) {
		printf("%d\n",pulse_width);
		/*ds_led_all_off();
		//print_info();
		//Test to determine if the user is pressing the button
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET && flag == 0){
			send_pulse();
			flag = 1;
		}
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == Bit_RESET && flag == 1){
			flag = 0;
		}

		while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6) != Bit_RESET){
			i++;
		}
		if(i>0){
			printf("\n %d",i);
			i=0;
		}*/		
	}
} 


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
	printf("%s %d",file,line);
  while (1);

}
#endif

