/* ds_sdcard.c ---
*
* Filename: ds_sdcard.c
* Description:
* Author: Enrique Areyan
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_sdcard.h>  // Pull in include files for F30x standard drivers 

void ds_sdcard_interface_init(void){
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	/* MOSI, MISO, SCK */
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	/* Chip Select Pin */
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC,&GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOB,13,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOB,14,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOB,15,GPIO_AF_5);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2 , ENABLE);
	SPI_I2S_DeInit(SPI2);
	SPI_InitTypeDef SPI_InitStructure;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_Init(SPI2, &SPI_InitStructure);
	SPI_RxFIFOThresholdConfig(SPI2, SPI_RxFIFOThreshold_QF);
	SPI_Cmd(SPI2, ENABLE);

	SD_CS_HIGH();

}

void ds_sdcard_readwrite(uint8_t *rxbuf, uint8_t *txbuf, int count) {
	int index;
	for (index=0;index<count;index++) {
		if (txbuf) {
			SPI_SendData8(SPI2, *txbuf++);
		}else {
			SPI_SendData8(SPI2, 0xFF);
		}
		while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE) == RESET);
		if (rxbuf) {
			*rxbuf++ = (uint8_t) SPI_ReceiveData8(SPI2);
		}else {
			SPI_ReceiveData8(SPI2);      
		}
	}
}

uint32_t get_fattime(void){
	uint32_t return_value = 9999;
	return return_value;
}

/* ds_sdcard.c ends here */
