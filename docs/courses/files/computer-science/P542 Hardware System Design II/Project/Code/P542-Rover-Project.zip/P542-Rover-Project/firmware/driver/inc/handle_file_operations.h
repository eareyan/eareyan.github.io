#include <ff.h>

FATFS Fatfs;		/* File system object */
FIL Fil;			/* File object */
BYTE Buff[128];		/* File read buffer */

FRESULT rc;				/* Result code */
DIR dir;				/* Directory object */
FILINFO fno;			/* File information object */
UINT bw, br, i;


void file_init(void);
void die(FRESULT rc);
void print_file_contents(char * file);
void print_root_contents(void);
void append_to_file(char * filename , char * data);
