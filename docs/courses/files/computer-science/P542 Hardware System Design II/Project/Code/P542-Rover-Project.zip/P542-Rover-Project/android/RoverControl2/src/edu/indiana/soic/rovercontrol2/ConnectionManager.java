package edu.indiana.soic.rovercontrol2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import android.util.Log;

public class ConnectionManager {
	
	private static String            THISCLASS = "BotCtl::ConnMgr"; 
	private static String            host      = null; // usually set to: "wifly8.soic.indiana.edu";
	private static int               port      = 0;    // usually set to: 2000;
	private static Socket            socket    = null;
	private static PrintWriter       out       = null;
	private static ConnectionManager instance  = new ConnectionManager();
	
	private ConnectionManager() {}
	
	public static synchronized ConnectionManager get() {
		if (instance == null){
			instance = new ConnectionManager();
		}
		
		if (socket == null) {
			socket = tryConnect();
		}
		
		return instance;
	}
	
	public static void setHost(String str) { host = str; }
	
	public static void setPort(int p) { port = p; }
	
	public static Socket getSocket() { return socket; }
	
	public static synchronized void disconnect() {
		if (socket != null) {
			RoverControl.closeConnection(socket, 0);
		}
		try {
			if (out != null)
				out.close();
			if (socket != null)
				socket.close();
			out = null;
			socket = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public static synchronized Socket tryConnect() {
		if (socket != null) {
			Log.v(THISCLASS, "Socket alive, returning (sock:" + socket + ")");
			return socket;
		}
		
		try {
			Log.v(THISCLASS, "Trying a connection to " + ConnectionManager.host + ":" + ConnectionManager.port);
			socket = new Socket(ConnectionManager.host, ConnectionManager.port);
		} catch (UnknownHostException e) {
			Log.e(THISCLASS, "Error: Can't find host " + e.getLocalizedMessage());
			ConnectActivity.setErrorString(e.getLocalizedMessage());
			return null;
		} catch (IOException e) {
			Log.e(THISCLASS, "Error: " + e.getLocalizedMessage());
			ConnectActivity.setErrorString(e.getLocalizedMessage());
			e.printStackTrace();
			return null;
		}
		
		return socket;
	}
	
	public static synchronized void sendCmd(Socket sock, String str) {
		Log.v (THISCLASS, "Sending message \"" + str + "\" to " + host + ":" + port + " (sock:" + socket + ")");
		
		try {
			out = new PrintWriter(sock.getOutputStream(), true);
			out.println(str);
		} catch (IOException e) {
			Log.e (THISCLASS, "Error in PrintWriter");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
	}
}



