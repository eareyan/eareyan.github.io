void ds_dac_channel_setup(void);
void ds_dac_init(void);
