package edu.indiana.soic.rovercontrol2;

import java.net.Socket;

import org.json.JSONObject;
import org.json.JSONException;

import android.util.Log;

public class RoverControl {

	private static String THISCLASS = "BotCtl::RoverControl";

	public static String ROVER_CMD_FORWARD  = "forward";
	public static String ROVER_CMD_BACKWARD = "backward";
	public static String ROVER_CMD_GO_LEFT  = "left";
	public static String ROVER_CMD_GO_RIGHT = "right";
	public static String ROVER_CMD_STOP     = "stop";

	public static String getJSON(int seq, String command, String param) {
		JSONObject o = new JSONObject();

		try {
			o.put("seq", seq);
			o.put("command", command);
			o.put("param", param);
		} catch (JSONException e) {
			Log.e (THISCLASS, "Error: JSON error");
			e.printStackTrace();
		}

		Log.v(THISCLASS, "JSON formed:" + o.toString());
		return o.toString();
	}

	// forward:
	public static void goForward(Socket sock, int seq) {
                Log.v (THISCLASS, "sending go-forward command");
		//String str = getJSON(seq, ROVER_CMD_FORWARD, "1");
		ConnectionManager.sendCmd(sock, "gf");
	}

	// back:
	public static void goBackward(Socket sock, int seq) {
                Log.v (THISCLASS, "sending go-backward command");
		//String str = getJSON(seq, ROVER_CMD_BACKWARD, "1");
		ConnectionManager.sendCmd(sock, "gb");
	}

	// left:
	public static void turnLeft(Socket sock, int seq) {
                Log.v (THISCLASS, "sending turn-left command");
		//String str = getJSON(seq, ROVER_CMD_GO_LEFT, "90");
		ConnectionManager.sendCmd(sock, "lf");
	}

	// right:
	public static void turnRight(Socket sock, int seq) {
		Log.v (THISCLASS, "sending turn-right command");
		//String str = getJSON(seq, ROVER_CMD_GO_RIGHT, "90");
		ConnectionManager.sendCmd(sock, "rf");
	}

	// stop:
	public static void stopRover(Socket sock, int seq) {
		Log.v (THISCLASS, "sending stop command");
		//String str = getJSON(seq, ROVER_CMD_STOP, "0");
		ConnectionManager.sendCmd(sock, "s");
	}

	public static void turnClockwise(Socket sock, int seq) {
		Log.v (THISCLASS, "sending clockwise command");
		ConnectionManager.sendCmd(sock, "c");
	}

	public static void turnCounterClockwise(Socket sock, int seq) {
		Log.v (THISCLASS, "sending counter-clockwise command");
		ConnectionManager.sendCmd(sock, "cc");
	}

	public static void closeConnection(Socket sock, int seq) {
		Log.v (THISCLASS, "sending exit command");
		ConnectionManager.sendCmd(sock, "e");
	}

}
