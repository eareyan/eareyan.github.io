P542-Rover-Project
==================

Quick notes on the pin connections:

 - UART breakout needs three pins: GND, RX and TX.  RX connects to PC4
   and TX connects to PC5.

 - Wifly needs four pins: GND, VDD-BATT, RX, TX.  VDD-BATT goes to 3V,
   RX goes PD8, TX goes to PD9.

