#include <ds_delay.h> 
#include <ds_sonar.h>


uint16_t IC2Value = 0;
uint16_t DutyCycle = 0;
uint32_t Frequency = 0;
RCC_ClocksTypeDef RCC_Clocks;

void ds_sonar_init(void){

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;     
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC , &GPIO_InitStructure);

	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOC,6,GPIO_AF_2);
	GPIO_PinAFConfig(GPIOC,7,GPIO_AF_2);

}

void send_pulse(void){

	SONAR_TRIGGER_LOW();
	ds_delay_uS(20);
	SONAR_TRIGGER_HIGH();
	ds_delay_uS(20);
	SONAR_TRIGGER_LOW();
}


void setup_timer(void){

	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
	TIM_ICInitStructure.TIM_ICPrescaler = 0x0;
	TIM_ICInitStructure.TIM_ICFilter = 0x0;
	TIM_ICInit(TIM3 , &TIM_ICInitStructure);


	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Falling;
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_IndirectTI;
	TIM_ICInitStructure.TIM_ICPrescaler = 0x0;
	TIM_ICInitStructure.TIM_ICFilter = 0x0;
	TIM_ICInit(TIM3 , &TIM_ICInitStructure);

	TIM_SelectInputTrigger(TIM3 , TIM_TS_TI1FP1);
	TIM_SelectSlaveMode(TIM3 , TIM_SlaveMode_Reset);
	TIM_SelectMasterSlaveMode(TIM3 , TIM_MasterSlaveMode_Enable);


	NVIC_InitTypeDef NVIC_InitStructure;
	/* Enable the TIM3 global Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}


void TIM3_IRQHandler(void)
{

	ds_led_on(8);
  RCC_GetClocksFreq(&RCC_Clocks);

  /* Clear TIM3 Capture compare interrupt pending bit */
  TIM_ClearITPendingBit(TIM3, TIM_IT_CC2);

  /* Get the Input Capture value */
  IC2Value = TIM_GetCapture2(TIM3);

  if (IC2Value != 0)
  {
    /* Duty cycle computation */
    DutyCycle = (TIM_GetCapture1(TIM3) * 100) / IC2Value;

    /* Frequency computation 
       TIM3 counter clock = (RCC_Clocks.HCLK_Frequency)/2 */

    Frequency = RCC_Clocks.HCLK_Frequency / IC2Value;
  }
  else
  {
    DutyCycle = 0;
    Frequency = 0;
  }
}

void print_info(void){

	printf("DutyCycle %d\n",DutyCycle);

}

