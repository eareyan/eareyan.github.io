void ds_a2d_init(void);
uint16_t ds_read_adc(void);
