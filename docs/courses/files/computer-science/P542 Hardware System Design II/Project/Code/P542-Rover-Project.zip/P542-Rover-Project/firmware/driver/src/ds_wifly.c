/* ds_uart.c --- 
 * 
 * Filename: ds_uart.c
 * Description: handles all functions related to the UART
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Tue Jan 15 11:12:30 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_uart.h>
#include <ds_wifly.h>
#include <string.h>

/* Code: */

queue_t rxbuf_wifly;
queue_t txbuf_wifly;


void flush_wifly(void) {
	USART_ITConfig(USART3,USART_IT_TXE,ENABLE); 
}

void USART3_IRQHandler(void){
	if(USART_GetFlagStatus(USART3, USART_FLAG_RXNE) != (uint16_t)RESET){
		int ch = USART_ReceiveData(USART3);
		enqueue(&rxbuf_wifly,ch); 
	}
	if (USART_GetFlagStatus(USART3,USART_FLAG_TXE) != (uint16_t)RESET) {
		int ch = dequeue(&txbuf_wifly);
		if (ch) {
			USART_SendData(USART3,ch);
		}else {
			USART_ITConfig(USART3,USART_IT_TXE,DISABLE); 
		}
	}
}


int putchar_wifly(int c){
	while(!enqueue(&txbuf_wifly,c));
	return 0;
}

int getchar_wifly(void) {
	int ch;
	while (!(ch=dequeue(&rxbuf_wifly)));
	return (ch);
}
int non_blocking_getchar_wifly(void){
	return dequeue(&rxbuf_wifly);
}

char* get_line_from_wifly(void){
	static char return_string[80]; //set a maximun of 80 characters to be read from user
	int i;
	/*Initialize de string to be all empty */
	for(i=0;i<80;i++){
		return_string[i] = 0;
	}

	int ch,counter = 0;
	/*get characters up to new line*/
	while ((ch=getchar_wifly()) != '\n'){
		return_string[counter] = ch;
		counter++;
	}
	/*Terminate the string*/
	return_string[counter] = 0;
	return return_string;
}


char* non_blocking_get_line_from_wifly(void){
	static char non_blocking_return_string_wifly[80]; //set a maximun of 80 characters to be read from user
	static int non_blocking_i_wifly;
	static int non_blocking_init_wifly=1;
	static int non_blocking_counter_wifly = 0;
	int ch = 0;
	if(non_blocking_init_wifly){
		/*Initialize de string to be all empty */
		for(non_blocking_i_wifly=0;non_blocking_i_wifly<80;non_blocking_i_wifly++){
			non_blocking_return_string_wifly[non_blocking_i_wifly] = 0;
		}
		non_blocking_init_wifly = 0;
		non_blocking_counter_wifly = 0;
	}
	/*get characters up to new line*/
	if((ch=non_blocking_getchar_wifly()) != 0){
		if(ch != '\n'){ // The line is not yet finished
			non_blocking_return_string_wifly[non_blocking_counter_wifly] = ch;
			non_blocking_counter_wifly++;
			return 0;
		}else{ // The line is finished
			non_blocking_init_wifly = 1;
			/*Terminate the string*/
			non_blocking_return_string_wifly[non_blocking_counter_wifly] = 0;
			flush_wifly();
			return non_blocking_return_string_wifly;
		}
	}else{
		return 0;
	}
}


void putstring_wifly(char *string){
	int i;
	for(i=0;i<strlen(string);i++){
		putchar_wifly(string[i]);
	}
}

void ds_wifly_init(void) {
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD,&GPIO_InitStructure);

	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;     
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD , &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOD,8,GPIO_AF_7);
	GPIO_PinAFConfig(GPIOD,9,GPIO_AF_7);

	//ASK BRYCE
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	USART_InitTypeDef USART_InitStructure;
	USART_StructInit(&USART_InitStructure);
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART3 ,&USART_InitStructure);
	USART_Cmd(USART3 , ENABLE);


	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	//NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x08;
	//NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x08;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x09;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x09;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);

	init_queue(&rxbuf_wifly);
	init_queue(&txbuf_wifly);
}

/* ds_uart.c ends here */
