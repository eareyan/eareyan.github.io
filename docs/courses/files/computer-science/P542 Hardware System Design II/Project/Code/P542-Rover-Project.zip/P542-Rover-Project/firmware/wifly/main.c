/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab2
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_systick.h> // Pull in include file for the local drivers
#include <ds_led.h>
#include <ds_uart.h>
#include <ds_rtc.h>
#include <ds_i2c.h>
#include <stdio.h>
#include <handle_user_input.h>
#include <ds_wifly.h>
#include <string.h>

int systick_flag;
void scheduler(void) {
	static int counter_100mS = 0; 
	static int counter_1000mS = 0; 

	if (counter_1000mS++==100) {
             //sample at 1 hz
             counter_1000mS=0;
             printf ("hello!\n");
	}

}

// Simple looping delay function
void delay(void) {
  int i = 5000000;
  while (i-- > 0) {
    asm("nop"); /* This stops it optimising code out */
  }
}

int main(void){
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	//Init systick
	ds_systick_init();	

        //Initialize uart
	uart_init();
        
	//Initialize clock
	ds_rtc_init();

        printf ("sending init command to wifly\n");
        ds_wifly_init();
        printf ("sent init command to wifly\n");
	char * client_data;
        while (1) {
		client_data = get_line_from_wifly();
                printf("%s",client_data);
                /* putchar_wifly(getchar()); */
                /* if (getchar()) { */
                /*         /\* putstring_wifly("42\n\r"); *\/ */
                /*         /\* putchar_wifly('A'); *\/ */
                /*         putchar_wifly('A'); */
                /*         putchar_wifly('B'); */
                /*         putchar_wifly('C'); */
                /*         putchar_wifly('\r'); */
                /*         putchar_wifly('\n'); */
                /* } */
                /* flush_wifly(); */
        }
    
        printf ("sending a HELLO to wifly\n");
        /* ds_wifly_send("HELLO"); */
        putchar_wifly('$');
        
        putstring_wifly("Hello!");
        printf ("sent a HELLO string to wifly\n");
        
        printf ("receiving data from wifly\n");
        char rxbuf[512];
    
        while (1) {
                /* memset(rxbuf, 0, 512); */
                /* ds_wifly_recv(rxbuf, 512); */
                char *rcv = get_line_from_wifly();
                if (strlen(rcv) > 0) {
                        printf ("received data from wifly: %s\n", rcv);
                } else {
                        printf ("no data from wifly\n");
                }
                delay();
        }
        

	/* char user_input; */
	/* while(1){ */
	/* 	//Poll user data from keyboard */
	/* 	user_input = non_blocking_getchar(); */
	/* 	if(user_input == 't' || user_input == 'T'){ //Got a T, read time from user */
	/* 		handler_user_input(); */
	/* 	} */
	/* 	if (systick_flag) { */
	/* 		systick_flag=0; */
	/* 		scheduler(); */
	/* 	} */
	/* } */
} 


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

