/* handle_user_input.h --- 
 * 
 * Filename: ds_uart.h
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Tue Jan 15 11:13:19 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */

void handler_user_input(void);
