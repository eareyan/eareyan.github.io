void ds_timer2_init(void);
void ds_timer2_setperiod(uint16_t period);
