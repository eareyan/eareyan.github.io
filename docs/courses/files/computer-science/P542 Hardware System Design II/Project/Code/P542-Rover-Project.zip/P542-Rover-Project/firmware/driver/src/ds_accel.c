/* ds_accel.c ---
*
* Filename: ds_i2c.c
* Description:
* Author:
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <ds_accel.h>

void ds_accel_init(void){
	uint8_t value = 0;
	value = 0x47;
	ds_i2c1_write(0x32, 0x20, &value);
	value = 0x90;
	ds_i2c1_write(0x32, 0x21, &value);
	value = 0x08;
	ds_i2c1_write(0x32, 0x23, &value);
}
void ds_accel_read(float *accel_data){
	uint8_t buffer[6]= {0};
	int i;
	int16_t raw_data[3] = {0};
	ds_i2c1_read(0x32,0x28,buffer,6);

	for (i=0; i<3; i++) {
		raw_data[i]=((int16_t)((uint16_t)buffer[2*i+1] << 8) + buffer[2*i])/(uint8_t)16;
		accel_data[i]=(float)raw_data[i]/1000.0;
	}
}
/* ds_accel.c ends here */
