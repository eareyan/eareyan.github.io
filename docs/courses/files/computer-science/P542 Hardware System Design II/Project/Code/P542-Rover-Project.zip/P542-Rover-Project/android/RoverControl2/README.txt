
Use Eclipse or ant to build stuff.

When using ant, build like so:

export ANDROID_HOME=~/android/adt/sdk
export JAVA_HOME=/usr/lib/jvm/java-6-sun
export ANDROID_SERIAL=016079B512027006
ant debug -Dsdk.dir=$ANDROID_HOME

