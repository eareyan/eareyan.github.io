package edu.indiana.soic.rovercontrol2;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.util.Log;

import java.net.Socket;

public class ConnectActivity extends Activity {

	private static String ACTIVITY = "BotCtl::Connect";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_connect);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.connect, menu);
		return true;
	}

	private static String errStr = "";
	
	public static void setErrorString(String error) {
		errStr = error;
	}

	private void showConnectionError(String host, int port) {
		// TODO: display connection error in a textarea.
		Log.e (ACTIVITY, "Can't connect to " + host + ":" + port  + 
				", reason: " + errStr);
		
		TextView tv = (TextView) findViewById(R.id.textView3);
		
		String error = " Can't connect to " + host + ":" + port  + 
				       "\nReason: " + errStr;
		
		tv.append(error);
	}
	
	// on "connect" button click
	public void doConnect(View view) {
		Log.d(ACTIVITY, "clicked connect button");
		// try to establish a connection to remote; if it doesn't work, report 
		// error; if it works, switch to the next activity.
		
		// just switch to the next activity for now.
		Intent intent     = new Intent(this, RoverControlActivity.class);

		EditText editTxt1 = (EditText) findViewById(R.id.editText1);
		EditText editTxt2 = (EditText) findViewById(R.id.editText2);

		//String host       = editTxt1.getText().toString();
		
		String hostStr = editTxt1.getText().toString();
		String portStr = editTxt2.getText().toString();
		
		Log.v (ACTIVITY, "txt1 = " + hostStr);
		Log.v (ACTIVITY, "txt2 = " + portStr);
		
		String host = "wifly8.soic.indiana.edu";
		int    port = 2000;
		
		if (hostStr != null && hostStr.length() != 0)
			host = hostStr;
		
		if (portStr != null && portStr.length() != 0)
			port = Integer.parseInt(portStr);
		
		Log.v (ACTIVITY, "Attempting a connection to " + host + ":" + port);
		
		ConnectionManager.setHost(host);
		ConnectionManager.setPort(port);
		Socket s = ConnectionManager.tryConnect();

		// TODO: display error in a textarea
		if (s == null) {
			showConnectionError(host, port);
			return;
		}
		
		TextView tv = (TextView) findViewById(R.id.textView3);
		tv.append(" success!");
		
		startActivity(intent);
	}
	
	public void doDisconnect(View view) {
		Log.v (ACTIVITY, "Clicked disconnect");
		ConnectionManager.disconnect();
		Log.v (ACTIVITY, "Done disconnect");
	}
}
