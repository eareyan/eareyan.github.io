
#include <stm32f30x.h>
#include <string.h>

#include "ds_systick.h"
#include "ds_uart.h"
#include "ds_rtc.h"
#include "ds_delay.h"
#include "ds_wifly.h"

#include <stdio.h>

// Simple looping delay function
void delay(void) {
  int i = 5000000;
  while (i-- > 0) {
    asm("nop"); /* This stops it optimising code out */
  }
}

void scheduler(void) {
  static int counter_100mS = 0;
  if (counter_100mS++==10) {
    counter_100mS=0;
    // tasks to accomplish at 100mS intervals
    /* handle_t_key(); */
    /* collect_data(); */
    printf ("counter:\n", counter_100mS);
    /* printf ("hello!\n"); */
  }
}

void init_stdio_bufs()
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

int main(int argc, char **argv)
{
    ds_systick_init();
    uart_init();
    ds_rtc_init();
    ds_delay_init();

    init_stdio_bufs();

    while (1) {
        if (systick_flag) {
            systick_flag = 0;
            scheduler();
        }
    }
    
    /* printf ("sending init command to wifly\n"); */
    
    /* ds_wifly_init(); */

    /* printf ("sent init command to wifly\n"); */
    
    /* printf ("sending a HELLO to wifly\n"); */
        
    /* ds_wifly_send("HELLO"); */
    
    /* printf ("sent a HELLO string to wifly\n"); */
        
    /* printf ("receiving data from wifly\n"); */
        
    /* char rxbuf[512]; */
    
    /* while (1) { */
    /*     memset(rxbuf, 0, 512); */
    /*     ds_wifly_recv(rxbuf, 512); */

    /*     /\* if (strlen(rxbuf) > 0) { *\/ */
    /*     /\*     printf ("received data from wifly: %s\n", rxbuf); *\/ */
    /*     /\* } *\/ */
        
    /*     delay(); */
    /* } */
    
    return 0;
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
	printf("%s %d",file,line);
  while (1);

}
#endif

