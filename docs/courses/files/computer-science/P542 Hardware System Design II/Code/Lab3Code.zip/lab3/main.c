/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab2
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers
#include <ds_userbutton.h>     // Pull in include file for the local drivers
#include <ds_uart.h>
#include <ds_gyro.h>
#include <stdio.h>

/* Controls the speed with which each leds turns on and off */
static int const COUNTER_DEFAULT = 100000;
/* Maps index to axis*/
const char *map_to_axis[] = {'X','Y','Z'};

/*
* Main function: implements the logic required for lab3.
*/

int main(void){
	enum { X , Y , Z } AXIS;
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//Initialize all leds
	ds_led_init();
	//Initialize user button
	ds_userbutton_init();
	//Initialize uart
	uart_init();
	//Initialize ds_gyro_interface_init
	ds_gyro_init();
	float data[3]= {0};
	char user_input;
	int CURRENT_AXIS = X;
	//Main loop
	while(1){
		//Poll Data from the Gyro
		ds_gyro_getdata(&data);	
		//Ask if the user pressed the button
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET){
			//Wait for the user to unpress the button
			while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET);
			//Go to next Axis
			CURRENT_AXIS = change_axis(CURRENT_AXIS,1); 
		}
		//Poll user data from keyboard
		user_input = non_blocking_getchar();
		if(user_input == 'X'){ //Got an X, change to that axis
			CURRENT_AXIS = change_axis(X,0);
		}else if(user_input == 'Y'){//Got an Y, change to that axis
			CURRENT_AXIS = change_axis(Y,0);
		}else if(user_input == 'Z'){//Got an Z, change to that axis
			CURRENT_AXIS = change_axis(Z,0);
		}
		/**
		* Implementation of State Machine
		*/
		switch(CURRENT_AXIS){
			case X: 
				handle_leds(data,0);
			break;
			case Y: 
				handle_leds(data,1);
			break;
			case Z: 
				handle_leds(data,2);
			break;
		}
	}
}
/*
* Helper function to print the new axis
*/
int change_axis(int old_axis,int next){
	int new_axis;
	//The second parameter of this function is just a boolean value
	if(next){
		new_axis = (old_axis+1)%3;
	}else{
		new_axis = old_axis;
	}
	//Print the new axis so that the user can see
	printf("\n Reading from axis: %c \n ", map_to_axis[new_axis]);
	return new_axis;
}
/*
* This function handles the lighting of the LEDS
*/
void handle_leds(float data[], int Axis_Number){

	//Any read from the gyro below 5 we are just going to ignore
	if(abs((int)data[Axis_Number]) > 5){
		printf("%c - axis: %f\n",map_to_axis[Axis_Number],data[Axis_Number]);
		ds_led_on(9);
	}else{
		ds_led_off(9);
	}
	//Ask what the value of the gyro is for the given axis and light LEDS accordingly
	if(((int)data[Axis_Number]) > 0){
		//Positive side
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 65)){
			ds_led_on(8);
		}else{
			ds_led_off(8);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 130)){
			ds_led_on(15);
		}else{
			ds_led_off(15);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 195)){
			ds_led_on(14);
		}else{
			ds_led_off(14);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 260)){
			ds_led_on(13);
		}else{
			ds_led_off(13);
		}

	}else{
		//Negative side
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -65){
			ds_led_on(10);
		}else{
			ds_led_off(10);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -130){
			ds_led_on(11);
		}else{
			ds_led_off(11);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -195){
			ds_led_on(12);
		}else{
			ds_led_off(12);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -260){
			ds_led_on(13);
		}else{
			ds_led_off(13);
		}

	}
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
