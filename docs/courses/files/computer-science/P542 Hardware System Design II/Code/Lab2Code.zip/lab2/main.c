/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab2
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers
#include <ds_userbutton.h>     // Pull in include file for the local drivers
#include <ds_uart.h>
#include <stdio.h>

/* Controls the speed with which each leds turns on and off */
static int const COUNTER_DEFAULT = 100000;
/* Controls the first led to be turn on */
static int const FIRST_LED = 8;
/* Maps from internal led numbering to labels. For instance, led number 8 is NE. Labesl 0-7 point to nothing*/
const char *map_to_led[] = {"","","","","","","","","NW","N","NE","E","SE","S","SW","W","NONE","ALL","NONE"};

/*
* Main function: implements the logic required for lab2.
*/
int main(void){
	//enum to define the states of the program
	enum {RUN = 0, PAUSE_FROM_BUTTON = 1, PAUSE_FROM_USER = 2}STATES;
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//Initialize all leds
	ds_led_init();
	//Initialize uart
	uart_init();
	//Initialize user button
	ds_userbutton_init();
	//Initialize some variables we are going to use later
	int i=FIRST_LED,CURRENT_LED=0,counter=COUNTER_DEFAULT,c,CURRENT_STATE = RUN;
	//Program body, runs forever
	while(1){
		//Get input from user
		c = non_blocking_getchar();
		//Switch according to the current state we are in
		switch(CURRENT_STATE){
			case RUN: //The lights are running freely
				if(counter>0){
					turn_leds_on(i); //Call function to turn on led
					CURRENT_LED = i; //Keep track of the current led
					counter--;
				}else{
					turn_leds_off(i); //Call function to turn off led
					//The next light cannot be more than 18 (state 16,18 is all off, state 17 is all on)
					i = ((i+1)% 19); 
					if(i==0){
						i = FIRST_LED; //This means that we are back at the first light
					}
					counter = COUNTER_DEFAULT; //Reset the counter
				}
				//Test to determine if the user is pressing the button
				if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET){
					CURRENT_STATE = PAUSE_FROM_BUTTON;					
					printf("%s\n",map_to_led[CURRENT_LED]);
				}
				//Test to determine if the user inputed a p via keyboard
				if(c=='p'){
					CURRENT_STATE = PAUSE_FROM_USER;
					printf("%s\n",map_to_led[CURRENT_LED]);
				}
				break;
			case PAUSE_FROM_BUTTON: //The user is pressing down the button
				if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == Bit_RESET){
					CURRENT_STATE = RUN; //The user unpress user button, return to RUN state
				}
				break;
			case PAUSE_FROM_USER: //The user inputed a p via keyboard 
				if(c=='r'){ 
					CURRENT_STATE = RUN;//The user inputed a r via keyboard, return to RUN state
				}
				break;
			}
		}
}
/*
* Function that proxies the number of the light to be turn on. The number i=16 represents all lights.
*/
void turn_leds_on(i){
	if(i==17){
		ds_led_all_on();
	}else{
		ds_led_on(i);
	}	
}
/*
* Function that proxies the number of the light to be turn off. The number i=16 represents all lights.
*/
void turn_leds_off(i){
	if(i==17){
		ds_led_all_off();
	}else{
		ds_led_off(i);
	}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
