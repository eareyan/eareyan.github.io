/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab7
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_systick.h> // Pull in include file for the local drivers
#include <ds_led.h>
#include <ds_uart.h>
#include <ds_rtc.h>
#include <ds_i2c.h>
#include <ds_gyro.h>
#include <ds_accel.h>
#include <ds_mag.h>
#include <stdio.h>
#include <ds_nordic.h>
#include <nrf24l01.h>


int main(void){
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	//Init systick
	ds_systick_init();	
	//Initialize i2c
	ds_i2c1_init();
	//Initialize uart
	uart_init();
	//Initialize clock
	ds_rtc_init();
	//Initialize delay
	ds_delay_init();
	//Initialize Nordic
	ds_nordic_init();
	
	nrf24l01_initialize_debug(false, 32, true);

	char user_input[32];
	char rxdata[32];

	while(1){

		user_input[0] = 'h';
		user_input[1] = 'o';
		user_input[2] = 'l';
		user_input[3] = 'a';
		user_input[4] = ' ';
		user_input[5] = 'e';
		user_input[6] = 'n';
		user_input[7] = 'r';
		user_input[8] = 'i';
		user_input[9] = 'q';
		user_input[10] = 'u';
		user_input[11] = 'e';
		user_input[12] = ' ';
		user_input[13] = '1';
		user_input[14] = '2';
		user_input[15] = '3';
		user_input[16] = 0;
		nrf24l01_clear_flush();

		nrf24l01_write_tx_payload(user_input, 32, true);      
		while(!(nrf24l01_irq_pin_active() && (nrf24l01_irq_tx_ds_active() || nrf24l01_irq_max_rt_active()))); 

		if (!nrf24l01_irq_max_rt_active()) {
			nrf24l01_irq_clear_all();
			nrf24l01_set_as_rx(true);
		}else {
			nrf24l01_flush_tx(); //get the unsent character out of the TX FIFO
			nrf24l01_irq_clear_all(); //clear all interrupts
			printf("Node: Failed to send %s\n",user_input);
		} 

		while(!(nrf24l01_irq_pin_active() && nrf24l01_irq_rx_dr_active()));
		nrf24l01_read_rx_payload(rxdata, 32);
		nrf24l01_irq_clear_all();

		printf("\nReceived: %s",rxdata);

		ds_delay_uS(130);
		nrf24l01_set_as_tx();
	}
} 


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
	printf("%s %d",file,line);
  while (1);

}
#endif

