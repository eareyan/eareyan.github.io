/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab2
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers
#include <ds_userbutton.h>     // Pull in include file for the local drivers
#include <ds_uart.h>
#include <ds_gyro.h>
#include <ds_i2c.h>
#include <ds_accel.h>
#include <ds_mag.h>
#include <stdio.h>
#include <math.h>

/* Controls the speed with which each leds turns on and off */
static int const COUNTER_DEFAULT = 100000;
static float const DEGREES = 180/3.14159265;
/* Maps index to axis*/
const char *map_to_axis[] = {'X','Y','Z'};
/*
* Helper function to print the tilted degree of an axis
*/
int parse_acce_data(float data,float total){
	return ((int)(asin(data/total)*DEGREES));
}
/*
* Main function: implements the logic required for lab4.
*/
int main(void){
	enum { X , Y , Z } AXIS;
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//Initialize all leds
	ds_led_init();
	//Initialize user button
	ds_userbutton_init();
	//Initialize uart
	uart_init();
	//Initialize ds_gyro_interface_init
	ds_gyro_init();
	//Initialize i2c
	ds_i2c1_init();
	//Initialize accelerometor
	ds_accel_init();

	float accel_data[3]= {0};
	float accel_total = 0;
	float gyro_data[3]= {0};
	char user_input;
	int CURRENT_AXIS = X;
	//Main loop
	while(1){
		//Poll Data from the Gyro
		ds_gyro_getdata(&gyro_data);	
		//Poll Data from the Accelerometor
		ds_accel_read(&accel_data);
		//Compute normalizer factor for the accelerometer
		accel_total = sqrt((accel_data[0]*accel_data[0]) + (accel_data[1]*accel_data[1]) + (accel_data[2]*accel_data[2]));
		//Ask if the user pressed the button
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET){
			//Wait for the user to unpress the button
			while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) != Bit_RESET);
			//Go to next Axis
			CURRENT_AXIS = change_axis(CURRENT_AXIS,1); 
		}
		//Poll user data from keyboard
		user_input = non_blocking_getchar();
		if(user_input == 'X'){ //Got an X, change to that axis
			CURRENT_AXIS = change_axis(X,0);
		}else if(user_input == 'Y'){//Got an Y, change to that axis
			CURRENT_AXIS = change_axis(Y,0);
		}else if(user_input == 'Z'){//Got an Z, change to that axis
			CURRENT_AXIS = change_axis(Z,0);
		}
		/**
		* Implementation of State Machine
		*/
		switch(CURRENT_AXIS){
			case X: 
				handle_leds(gyro_data,0,parse_acce_data(accel_data[0],accel_total));
			break;
			case Y: 
				handle_leds(gyro_data,1,parse_acce_data(accel_data[1],accel_total));
			break;
			case Z: 
				handle_leds(gyro_data,2,parse_acce_data(accel_data[2],accel_total));
			break;
		}
	}
}
/*
* Helper function to print the new axis
*/
int change_axis(int old_axis,int next){
	int new_axis;
	//The second parameter of this function is just a boolean value
	if(next){
		new_axis = (old_axis+1)%3;
	}else{
		new_axis = old_axis;
	}
	//Print the new axis so that the user can see
	printf("\n Reading from axis: %c \n ", map_to_axis[new_axis]);
	return new_axis;
}
/*
* This function handles the lighting of the LEDS and printing of information
*/
void handle_leds(float data[], int Axis_Number, int Tilt_Angle){

	//Any read from the gyro below 5 we are just going to ignore
	if(abs((int)data[Axis_Number]) > 5){
		printf("%c-axis: %11f - angle : %d\n",map_to_axis[Axis_Number],data[Axis_Number],Tilt_Angle);
		ds_led_on(9);
	}else{
		ds_led_off(9);
	}
	//Ask what the value of the gyro is for the given axis and light LEDS accordingly
	if(((int)data[Axis_Number]) > 0){
		//Positive side
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 65)){
			ds_led_on(8);
		}else{
			ds_led_off(8);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 130)){
			ds_led_on(15);
		}else{
			ds_led_off(15);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 195)){
			ds_led_on(14);
		}else{
			ds_led_off(14);
		}
		if((abs((int)data[Axis_Number]) > 5) && (((int)data[Axis_Number]) > 260)){
			ds_led_on(13);
		}else{
			ds_led_off(13);
		}

	}else{
		//Negative side
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -65){
			ds_led_on(10);
		}else{
			ds_led_off(10);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -130){
			ds_led_on(11);
		}else{
			ds_led_off(11);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -195){
			ds_led_on(12);
		}else{
			ds_led_off(12);
		}
		if(((int)data[Axis_Number])< -5 && ((int)data[Axis_Number])< -260){
			ds_led_on(13);
		}else{
			ds_led_off(13);
		}

	}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
