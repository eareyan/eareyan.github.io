/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: Tue Jan 22
 *           By: Enrique Areyan
 *     Update #: 2
 * Keywords: lab2, p542
 * Compatibility: 
 * 
 */

/* Commentary: 
 * Implementation of lab2
 * 
 */

/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_systick.h> // Pull in include file for the local drivers
#include <ds_led.h>
#include <ds_uart.h>
#include <ds_rtc.h>
#include <ds_i2c.h>
#include <ds_gyro.h>
#include <ds_accel.h>
#include <ds_mag.h>
#include <stdio.h>
#include <handle_user_input.h>


int systick_flag;
float gyro_data[3]= {0};
float accel_data[3]= {0};
float mag_data[3]= {0};

void sample(float * input_data,float * output_data){
	output_data[0] = output_data[0] + input_data[0]; 
	output_data[1] += input_data[1];
	output_data[2] += input_data[2];
}

void clean_sample(float * sample_data[]){
	sample_data[0] = 0;
	sample_data[1] = 0;
	sample_data[2] = 0;	
}

void scheduler(void) {
	static float output_gyro_data[3] = {0};
	static int gyro_count_samples = 0;
	static float output_accel_data[3] = {0};
	static int accel_count_samples = 0;
	static float output_mag_data[3] = {0};
	static int mag_count_samples = 0;

	static int counter_100mS = 0; 
	static int counter_1000mS = 0; 

	if (counter_100mS++==10) {
	//sample at 10 hz
		counter_100mS=0;
		//Poll Data from the Gyro
		ds_gyro_getdata(&gyro_data);
		sample(&gyro_data,&output_gyro_data);
		gyro_count_samples++;
		//Poll Data from the Accelerometor
		ds_accel_read(&accel_data);
		sample(&accel_data,&output_accel_data);
		accel_count_samples++;
		//Poll Data from the Magnetometer
		ds_mag_read(&mag_data);
		sample(&mag_data,&output_mag_data);
		mag_count_samples++;
	}
	if (counter_1000mS++==100) {
	//sample at 1 hz
		counter_1000mS=0;
		//Print info
		printf("\n%d/%d/%d,%d:%d:%d,% 08.5f,% 08.5f,% 08.5f,% 08.5f,% 08.5f,% 08.5f,% 08.5f,% 08.5f,% 08.5f",
			get_month(),get_date(),get_year(),get_hours(),get_minutes(),get_seconds(),
			output_gyro_data[0] / gyro_count_samples,	output_gyro_data[1] / gyro_count_samples,	output_gyro_data[2] / gyro_count_samples,
			output_accel_data[0]/ accel_count_samples,	output_accel_data[1]/ accel_count_samples,	output_accel_data[2]/ accel_count_samples,
			output_mag_data[0]  / mag_count_samples,	output_mag_data[1]  / mag_count_samples,	output_mag_data[2]  / mag_count_samples);
		//Reset counters
		gyro_count_samples = 0;
		accel_count_samples = 0;
		mag_count_samples = 0;
		clean_sample(&output_gyro_data);
		clean_sample(&output_accel_data);
		clean_sample(&output_mag_data);
	}

}

int main(void){
	//Set not buffer
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	//Init systick
	ds_systick_init();	
	//Initialize i2c
	ds_i2c1_init();
	//Initialize uart
	uart_init();
	//Initialize clock
	ds_rtc_init();
	//Initialize ds_gyro_interface_init
	ds_gyro_init();
	//Initialize accelerometor
	ds_accel_init();
	//Initialize magnetometer
	ds_mag_init();


	char user_input;
	while(1){
		//Poll user data from keyboard
		user_input = non_blocking_getchar();
		if(user_input == 't' || user_input == 'T'){ //Got a T, read time from user
			handler_user_input();
		}
		if (systick_flag) {
			systick_flag=0;
			scheduler();
		}

	}


} 


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

