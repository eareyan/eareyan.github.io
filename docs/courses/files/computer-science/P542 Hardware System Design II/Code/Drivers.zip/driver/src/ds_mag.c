/* ds_mag.c ---
*
* Filename: ds_mag.c
* Description:
* Author:
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <ds_mag.h>

void ds_mag_init(void){
	uint8_t value = 0;
	value = 0x14;
	ds_i2c1_write(0x3C, 0x00, &value);
	value = 0xE0;
	ds_i2c1_write(0x3C, 0x01, &value);
	value = 0x00;
	ds_i2c1_write(0x3C, 0x02, &value);
}
void ds_mag_read(float *mag_data){
	uint8_t buffer[6]= {0};
	int i;

	ds_i2c1_read(0x3C,0x03,buffer,2);
	ds_i2c1_read(0x3C,0x07,buffer+2,2);
	ds_i2c1_read(0x3C,0x05,buffer+4,2);

	for (i=0; i<2; i++) {
		mag_data[i]=(float)((int16_t)(((uint16_t)buffer[2*i] << 8) + buffer[2*i+1]))/230;
	}
	mag_data[2]=(float)((int16_t)(((uint16_t)buffer[4] << 8) + buffer[5]))/205;
}
/* ds_mag.c ends here */
