#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 

void ds_nordic_init(void);
uint8_t ds_nordic_send_spi_byte(uint8_t data);
