/* led.h --- 
 * 
 * Filename: led.h
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 10:56:56 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */

extern int systick_flag;

void ds_systick_init(void);
void SysTick_Handler(void);

/* led.h ends here */
