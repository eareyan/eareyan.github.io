/* led.c --- 
 * 
 * Filename: led.c
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 10:53:06 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */
#include <stm32f30x.h>
#include <ds_systick.h>
#include <ds_uart.h>

int systick_flag = 1;

void ds_systick_init(void) {
  SysTick_Config(SystemCoreClock/100);
}

void SysTick_Handler(void) {
	if(!queue_empty(&txbuf)){
		flush_uart();
	}
	systick_flag = 1;
}

