/* ds_delay.h ---
*
* Filename: ds_delay.h
* Description:
* Author: Enrique Areyan
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 

void ds_delay_init(void);

void ds_delay_uS(uint16_t uS_count);
