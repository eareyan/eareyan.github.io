/* handle_user_input.c --- 
 * 
 * Filename: handle_user_input.c
 * Description:  handle the user's input (time and date) for lab 5.
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Thu Feb 14 5:00:00 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */
#include <stm32f30x.h>
#include <handle_user_input.h>
#include <stdio.h>

/*
* Handle the input of the user for just one pice of data. This function gets call for month,day,year,hours,minutes and seconds
*/
int handle_piece_data(char * name_data,char * format, int low_range,int high_range){
	char * user_data;	
	int prompt_for_data = 1, user_data_int_value;
	while(prompt_for_data){
		printf("\nInput %s format %s:",name_data,format);
		user_data = get_line_from_user();
		user_data_int_value = (int) strtol(user_data, NULL, 10);
		if(user_data_int_value < low_range || user_data_int_value > high_range){
			printf("\n---Invalid %s, please try again---\n",name_data);
		}else{
			prompt_for_data = 0;
		}
	}
	return user_data_int_value;
}


/*
* Handle the input data from the user
*/
void handler_user_input(void){
	int user_month_value,user_day_value,user_year_value,user_hours_value,user_minutes_value,user_seconds_value;
	//Flush the first character receive, a nl
	get_line_from_user();
	//Poll data from user
	user_month_value = handle_piece_data("month","MM", 1, 12);
	user_day_value   = handle_piece_data("day"  ,"DD", 1, 31);
	user_year_value  = handle_piece_data("year" ,"YY", 1, 99);
	//Poll time from user
	user_hours_value   = handle_piece_data("hours"  ,"HH", 0, 24);
	user_minutes_value = handle_piece_data("minutes","MM", 0, 60);
	user_seconds_value = handle_piece_data("seconds","SS", 0, 60);
	//Update rtc date
	update_rtc_date_values(user_year_value,user_month_value,user_day_value,RTC_Weekday_Friday);
	update_rtc_time_values(user_hours_value,user_minutes_value,user_seconds_value);
}

