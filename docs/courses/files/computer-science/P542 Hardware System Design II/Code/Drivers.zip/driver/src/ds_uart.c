/* ds_uart.c --- 
 * 
 * Filename: ds_uart.c
 * Description: handles all functions related to the UART
 * Author: Enrique Areyan
 * Maintainer: 
 * Created: Tue Jan 15 11:12:30 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_uart.h>

/* Code: */

queue_t rxbuf;
queue_t txbuf;


void flush_uart(void) {
	USART_ITConfig(USART1,USART_IT_TXE,ENABLE); 
}

void USART1_IRQHandler(void){
	if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != (uint16_t)RESET){
		int ch = USART_ReceiveData(USART1);
		enqueue(&rxbuf,ch); 
	}
	if (USART_GetFlagStatus(USART1,USART_FLAG_TXE) != (uint16_t)RESET) {
		int ch = dequeue(&txbuf);
		if (ch) {
			USART_SendData(USART1,ch);
		}else {
			USART_ITConfig(USART1,USART_IT_TXE,DISABLE); 
		}
	}
}

void init_queue(queue_t * q){
	q->head = 0;
	q->tail = 0;
}

void print_queue(queue_t q){
	int i=0;
	for(i = 0;i < QUEUE_SIZE;i++){
		printf("head = %d, tail = %d, queue[%d] = %d\n",q.head,q.tail,i,q.buffer[i]);
	}
}

/*
* Adds an int to the buffer. This function return 1 when the character was successfully added and 0 when the buffer did not have room to add the character
*/
int enqueue(queue_t * q, int n){ 
	if(queue_full(q)){
		//There is no room for the value in the buffer
		return 0;
	}else{
		//There is room in the buffer, enqueue
		q->buffer[q->head] = n;
		q->head = (q->head + 1) % QUEUE_SIZE;
		return 1;
	}
}
/*
* Remove a character from the buffer. If the buffer is empty, 0 should be returned.
*/
int dequeue(queue_t * q){
	int return_value;
	if(queue_empty(q)){
		//Nothing to dequeue
		return_value = 0;
	}else{
		return_value = q->buffer[q->tail];
		q->buffer[q->tail] = 0;
		q->tail = (q->tail + 1) % QUEUE_SIZE;
	}
	return return_value;
}

/*
*	Checks if the queue is full. If it is, return 1, otherwise returns 0
*/
int queue_full(queue_t * q){
	if(((q->head+1) % QUEUE_SIZE) == q->tail){
		return 1; //queue full
	}else{
		return 0; //queue not full
	}
}
/*
* Returns 1 if the buffer is empty and 0 otherwise.
*/
int queue_empty(queue_t * q){
	if(q->head == q->tail){
		return 1;
	}else{
		return 0;
	}
}

int putchar(int c){
	while(!enqueue(&txbuf,c));
	return 0;
}

int getchar(void) {
	int ch;
	while (!(ch=dequeue(&rxbuf)));
	return (ch);
}
int non_blocking_getchar(void){
	return dequeue(&rxbuf);
}

char* get_line_from_user(void){
	char return_string[80]; //set a maximun of 80 characters to be read from user
	int i;
	/*Initialize de string to be all empty */
	for(i=0;i<80;i++){
		return_string[i] = 0;
	}

	int ch,counter = 0;
	/*get characters up to new line*/
	while ((ch=getchar()) != '\n'){
		return_string[counter] = ch;
		counter++;
	}
	/*Terminate the string*/
	return_string[counter] = 0;
	return return_string;
}
void putstring(char *string){
	int i;
	for(i=0;i<strlen(string);i++){
		putchar(string[i]);
	}
}

void uart_init(void){
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC,&GPIO_InitStructure);

	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;     
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC , &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOC,4,GPIO_AF_7);
	GPIO_PinAFConfig(GPIOC,5,GPIO_AF_7);


	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	USART_InitTypeDef USART_InitStructure;
	USART_StructInit(&USART_InitStructure);
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1 ,&USART_InitStructure);
	USART_Cmd(USART1 , ENABLE);


	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x08;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x08;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);

	init_queue(&rxbuf);
	init_queue(&txbuf);
}

/* ds_uart.c ends here */
