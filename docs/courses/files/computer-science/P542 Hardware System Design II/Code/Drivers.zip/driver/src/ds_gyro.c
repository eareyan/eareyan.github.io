/* ds_gyro.c ---
*
* Filename: ds_gyro.c
* Description:
* Author:
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_gyro.h>  // Pull in include files for F30x standard drivers 

void ds_gyro_interface_init(void){
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOE, ENABLE);
	/* MOSI, MISO, SCK */
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_6 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	/* Chip Select Pin */
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOE,&GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOA,5,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOA,6,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOA,7,GPIO_AF_5);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1 , ENABLE);
	SPI_I2S_DeInit(SPI1);
	SPI_InitTypeDef SPI_InitStructure;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_Init(SPI1, &SPI_InitStructure);
	SPI_RxFIFOThresholdConfig(SPI1, SPI_RxFIFOThreshold_QF);
	SPI_Cmd(SPI1, ENABLE);

}

void ds_gyro_init(void){
	uint8_t ctrl1 = 0x00;
	uint8_t ctrl4 = 0x00;

	ds_gyro_interface_init();

	ctrl1 |= (uint8_t) (((uint8_t)0x00) |\
                   ((uint8_t)0x30) |\
		   ((uint8_t)0x08) |\
		   ((uint8_t)0x07)); 
	ds_gyro_write(&ctrl1, 0x20,1);

	ctrl4 |= (uint8_t) (((uint8_t)0x00) |\
                    ((uint8_t)0x00) |\
		    ((uint8_t)0x10));  
	ds_gyro_write(&ctrl4, 0x23,1);


}

static uint8_t ds_gyro_sendbyte(uint8_t byte){
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); 
	SPI_SendData8(SPI1, byte);
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
	return (uint8_t)SPI_ReceiveData8(SPI1);
}

void ds_gyro_read(uint8_t* pBuffer, uint8_t ReadAddr, uint16_t NumByteToRead){
	if (NumByteToRead > 0x01) {
	  ReadAddr |= (uint8_t)(0x80 | 0x40); // If sending more that one byte set multibyte commands
	}
	else {
	  ReadAddr |= (uint8_t) (0x80); // Else just set the read mode 
	}
	GYRO_CS_LOW();
	ds_gyro_sendbyte(ReadAddr);
	while(NumByteToRead > 0x00) {
	  *pBuffer = ds_gyro_sendbyte(((uint8_t)0x00));
	  NumByteToRead--;
	  pBuffer++;
	}
	GYRO_CS_HIGH();
}
void ds_gyro_write(uint8_t* pBuffer, uint8_t WriteAddr, uint16_t NumByteToRead){
	if (NumByteToRead > 0x01) {
	  WriteAddr |= (uint8_t)(0x40); // If sending more that one byte set multibyte commands
	}
	GYRO_CS_LOW();
	ds_gyro_sendbyte(WriteAddr);
	while(NumByteToRead > 0x00) {
	  ds_gyro_sendbyte(*pBuffer);
	  NumByteToRead--;
	  pBuffer++;
	}
	GYRO_CS_HIGH();
}
void ds_gyro_getdata(float *pfData){
	uint8_t tmpbuffer[6]= {0};
	int i;
	int16_t RawData[3] = {0};
	ds_gyro_read(&tmpbuffer,0x28,6); 
	for(i=0; i<3; i++) {
	  RawData[i]=(int16_t)(((uint16_t)tmpbuffer[2*i+1] << 8) + tmpbuffer[2*i]);
	}
	for(i=0; i<3; i++) {
	  pfData[i]=(float)RawData[i]/GYRO_Sensitivity_500dps;
	}
}
/* ds_gyro.c ends here */
