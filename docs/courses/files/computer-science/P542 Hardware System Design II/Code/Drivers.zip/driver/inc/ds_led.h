/* led.h --- 
 * 
 * Filename: led.h
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 10:56:56 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */

void ds_led_init(void);
void ds_led_on(int led); 
void ds_led_off(int led); 
void ds_led_all_on(void);
void ds_led_all_off(void);

/* led.h ends here */
