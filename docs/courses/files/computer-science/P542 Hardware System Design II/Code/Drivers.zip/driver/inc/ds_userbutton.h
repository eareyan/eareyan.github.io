/* led.h --- 
 * 
 * Filename: led.h
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 10:56:56 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */

void ds_userbutton_init(void);

/* led.h ends here */
