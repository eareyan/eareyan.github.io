/* ds_uart.h --- 
 * 
 * Filename: ds_uart.h
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Tue Jan 15 11:13:19 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */

/* Code: */

#define QUEUE_SIZE 128

typedef struct queue {
  int head;
  int tail;
  int buffer[QUEUE_SIZE];
} queue_t;

extern queue_t rxbuf;
extern queue_t txbuf;

void flush_uart(void);

void USART1_IRQHandler(void);

void init_queue(queue_t *);

int enqueue(queue_t *, int);

int dequeue(queue_t *);

int queue_empty(queue_t *); 

int queue_full(queue_t * q);

int putchar(int);

int getchar(void);

char * getstring(void);

void putstring(char *string);

void uart_init(void);

/* ds_uart.h ends here */
