/* ds_sdcard.h ---
*
* Filename: ds_sdcard.h
* Description:
* Author: Enrique Areyan
* Maintainer:
* Created: Thu Jan 24 05:43:27 2013 (-0500)
* Version:
* Last-Updated:
* By:
* Update #: 0
* URL:
* Doc URL:
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change Log:
*
*
*/
/* Code: */
#include <stm32f30x.h>

#define SD_CS_LOW()   GPIO_ResetBits(GPIOC, GPIO_Pin_0);
#define SD_CS_HIGH()  GPIO_SetBits(GPIOC, GPIO_Pin_0);

void ds_sdcard_interface_init(void);

void ds_sdcard_readwrite(uint8_t *rxbuf, uint8_t *txbuf, int count);

uint32_t get_fattime(void);

/* ds_sdcard.h ends here */
