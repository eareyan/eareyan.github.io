/* ds_accel.c ---
*
* Filename: ds_i2c.c
* Description:
* Author:
* Maintainer:
* Created: Fri Jan 25 08:34:50 2013
* Last-Updated:
* By:
* Update #: 0
* Keywords:
* Compatibility:
*
*/

/* Commentary:
*
*
*
*/

/* Change log:
*
*
*/

/* Code: */
#include <stm32f30x.h>
#include <ds_rtc.h>


RTC_TimeTypeDef  RTC_TimeStructure;
RTC_DateTypeDef  RTC_DateStructure;
RTC_InitTypeDef  RTC_InitStructure;


void update_rtc_date_values(int year,int month,int day,int weekday){
	RTC_DateStructure.RTC_Year 	= year;
	RTC_DateStructure.RTC_Month 	= month;
	RTC_DateStructure.RTC_Date 	= day;
	RTC_DateStructure.RTC_WeekDay 	= weekday;
	RTC_SetDate(RTC_Format_BCD, &RTC_DateStructure);
}

void update_rtc_time_values(int hours,int minutes,int seconds){
	RTC_TimeStructure.RTC_H12 	= RTC_H12_AM;
	RTC_TimeStructure.RTC_Hours	= hours;
	RTC_TimeStructure.RTC_Minutes	= minutes;
	RTC_TimeStructure.RTC_Seconds	= seconds;  
	RTC_SetTime(RTC_Format_BIN, &RTC_TimeStructure);
}


void ds_rtc_init(void){

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	PWR_BackupAccessCmd(ENABLE);   
	RCC_BackupResetCmd(ENABLE);
	RCC_BackupResetCmd(DISABLE);
	PWR_BackupAccessCmd(ENABLE);
	RCC_LSICmd(ENABLE);
	while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);
	RCC_RTCCLKCmd(ENABLE);
	RTC_WaitForSynchro(); 

	RTC_StructInit(&RTC_InitStructure);
	RTC_InitStructure.RTC_HourFormat = RTC_HourFormat_24;
	RTC_InitStructure.RTC_AsynchPrediv = 88;
	RTC_InitStructure.RTC_SynchPrediv = 470;
	RTC_Init(&RTC_InitStructure); 

	update_rtc_date_values(13,RTC_Month_February,8,RTC_Weekday_Friday);
	update_rtc_time_values(0x09,0x05,0x00);
}

uint8_t get_year(void){
	RTC_GetDate(RTC_Format_BIN, &RTC_DateStructure); 
	return RTC_DateStructure.RTC_Year;
}
uint8_t get_month(void){
	RTC_GetDate(RTC_Format_BIN, &RTC_DateStructure); 
	return RTC_DateStructure.RTC_Month;
}
uint8_t get_date(void){
	RTC_GetDate(RTC_Format_BIN, &RTC_DateStructure); 
	return RTC_DateStructure.RTC_Date;
}
uint8_t get_week_day(void){
	RTC_GetDate(RTC_Format_BIN, &RTC_DateStructure); 
	return RTC_DateStructure.RTC_WeekDay;
}


uint8_t get_hours(void){
	RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure); 
	return RTC_TimeStructure.RTC_Hours;
}
uint8_t get_minutes(void){
	RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure); 
	return RTC_TimeStructure.RTC_Minutes;
}
uint8_t get_seconds(void){
	RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure); 
	return RTC_TimeStructure.RTC_Seconds;
}

/* ds_rtc.c ends here */
