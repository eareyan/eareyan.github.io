/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: 
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */
/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <ds_led.h>     // Pull in include file for the local drivers

// Simple looping delay function
void delay(void) {
  int i = 200000;
  while (i > 0) {
    asm("nop"); /* This stops it optimising code out */
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == Bit_RESET){
		i--;
	}
  }
}

int main(void) { 
	//Initialize all leds
	ds_led_init();
	//Initialize USER & WAKE Button
	/*This entire code is to control de User button */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_StructInit(&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	int i=8;
	while (1){
		//Turn all lights on, then delay, then turn off
		ds_led_on(i);
		delay();
		ds_led_off(i);
		//if i==0 we have gone through the one cycle
		if(i==0){
			i=7;
			ds_led_all_on();
			delay();
			ds_led_all_off();
			delay();
		}else{
		//Adjust to turn on the right led since led numbers run from 8 through 15
			i = (i+1) % 16;
		}
	}  
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
