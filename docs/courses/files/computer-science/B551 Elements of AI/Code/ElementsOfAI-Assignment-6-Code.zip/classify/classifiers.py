import os
import sys
import utils
import random

########################################################################################
# Naive Bayesian Classifier
########################################################################################
class NaiveBayesClassifier():
	"""
	A Naive Bayes classifier.  
	Naive Bayes classifiers use two probability distributions: 
       - P(label) gives the probability that an input will receive each 
         label, given no information about the input's features. 
       - P(fname=fval|label) gives the probability that a feature 
         (fname) will be a value (fval), given the label (label). 
	"""
	def __init__(self):
		pass
		
	def train(self,examples,featureset):
		"""
                Implement this for Problem I
                
		featureset - set of features
			eg) set(['EXIST_to', 'EXIST_its', 'EXIST_of'])
		examples - list of examples
			An example is a tuple (features, label) while features is a dictionary of feature name:value pair
			eg)
			[
			({'EXIST_its': False, 'EXIST_of': True, 'EXIST_to': False}, 'cat1')
			({'EXIST_its': False, 'EXIST_of': True, 'EXIST_to': False}, 'cat2')
			({'EXIST_its': False, 'EXIST_of': False, 'EXIST_to': False}, 'cat1')
			({'EXIST_its': False, 'EXIST_of': False, 'EXIST_to': False}, 'cat1')
			({'EXIST_its': True, 'EXIST_of': True, 'EXIST_to': True}, 'cat1')
			({'EXIST_its': True, 'EXIST_of': True, 'EXIST_to': True}, 'cat1')
			({'EXIST_its': False, 'EXIST_of': False, 'EXIST_to': False}, 'cat1')
			({'EXIST_its': True, 'EXIST_of': True, 'EXIST_to': True}, 'cat2')
			({'EXIST_its': False, 'EXIST_of': True, 'EXIST_to': True}, 'cat2')
			({'EXIST_its': False, 'EXIST_of': True, 'EXIST_to': False}, 'cat1')
			...
			]

		This method constructs probability distributions for  P(label), P(fname=fval|label) 
		"""
		
		# Get the list of labels. eg) ['cat1','cat2','cat1','cat1','cat1',...]
		# Get a list of feature values for each (label,fname) values in the examples
		# 	which means for 2 labels and 10 features, we will have 2*10 probability distributions
		labels = []
		vals = {}	# note this is a dictionary of the key:value pair (label,fname):list(fval)
		for features, label in examples: 
			labels.append(label)
			for fname, fval in features.items(): 
				if (label,fname) not in vals:
					vals[(label,fname)] = []
				vals[(label,fname)].append(fval)
		
		# save the label list for possible future use
		self.labelset = set(labels)
		
		# get P(label)
		# construct a ProbDist (probability distribution) with the list 'labels'
		# Using 'utils.ProbDist()' will make it as simple as one line of code

		# Put your code	here
		self.probLabels = utils.ProbDist(labels,False)	#probability of labels. save it for later use
		
		# get P(fname=fval|label)
		# construct probability distributions with the dictionary 'vals' whose values are lists of feature values
		# Again use 'utils.ProbDist()'
		# Put your code here
		self.dataDistribution = {} 		#a dictionary containing P(fname=fval|label), and save it for later use
		for cat,feature in vals:		#for each feature and category in vals, calculate its probability 
			#print cat,",",feature
			self.dataDistribution[(cat,feature)] = utils.ProbDist(vals[cat,feature],False)
		#print. only for debbugging purposes
		#print self.probLabels
		#print self.dataDistribution
		#for label,feature in self.dataDistribution:
		#	print label,",",feature,",\t",self.dataDistribution[(label,feature)].get(True)," : ",self.dataDistribution[(label,feature)].get(False)
		#test the use of the trained data
		#print self.dataDistribution
		#print 'Probability of cat1,EXIST_of being true'
		#print self.dataDistribution[('cat1','EXIST_of')].get(True)
	def test_one(self,features):
		"""
                Implement this for Problem I

		Given a series of features corresponding to a text file,
		Compute log P(label|features) = log P(label) + log P(features|label) for each label
		and return the label that maximizes this expression.
		
		features is a dictory of feature_name:value pair
		eg) {'EXIST_its': True, 'EXIST_of': True, 'EXIST_to': True}
		"""
		decision = {}
		#print features
		#loop through the labels
		for label in self.labelset:
			#loop through the features
			decision[label] = self.probLabels.getLogP(label);
			for feature in features:
				#This text has this feature
				if(features[feature] == True):
					#calculate log P(label|features)- bayes rule
					decision[label] = decision[label] + self.dataDistribution[(label,feature)].getLogP(True) 
					#decision[label] = decision[label] + self.dataDistribution[(label,feature)].getLogP(features[feature]) 
			#print label,":",decision[label]
		# Replace the following line with your code.
		# For your convenience, 'utils.get_maxitem(dict)' returns the key whose value is the maximum in the dictionary
		#print decision
		return utils.get_maxitem(decision)

				
########################################################################################
# Decision Tree Classifier
########################################################################################
class DTNode():
	"""
	Decision Tree node class
	For a branching node, self.name is the feature name and 
	self.branch is a dictionary from feature values -> subtree (a subtree is also a DTNode)
	For a leaf node, self.name represents the label
	"""
	def __init__(self,name=None,branch=None):
		self.name = name
		self.branch = branch

	def show(self,indent):
		"""
		This pretty prints the tree structure.
		Looks good for the feature value 'True/False' but works for others as well
		"""
		name = self.name
		if name == None:
			name = "None"
		elif isinstance(name,int):
			name = "%d" % name
		s = indent + name + "\n"
		if self.branch != None:
			for val in self.branch:
				if val == True:
					v = 't'
				elif val == False:
					v = 'f'
				else:
					v = '|'
				s += self.branch[val].show(indent+v+" ")
		return s

	def classify(self,features):
		"""
		Given a new example (dictionary of features:values), descend the tree
		until a leaf is reached.
		
		If a feature value of the example is missing from the node's branching structure
		(because it hasn't been seen before during training), then an arbitrary
		branch is taken instead.
		"""
		if self.branch != None:	
			fval =  features[self.name]
			if fval in self.branch:
				return self.branch[fval].classify(features)
			else:	# havn't seen this case in training examples
				anykey = self.branch.keys()[0]
				return self.branch[anykey].classify(features)
		else:	# leaf node. in this case, its name is a label not a feature name
			return self.name
			
class DecisionTreeClassifier():
	"""
	"""
	def __init__(self):
		pass
		
	def train(self,examples,featureset):
		"""
		"""
		self.tree = self.decision_tree_learning(examples,featureset.copy())
		print self.tree.show("")
	
	def decision_tree_learning(self,examples,featuresett):
		"""
                Implement this for Problem II
                
		examples - list of examples
		featureset - set of available features
		
		Return value is a DTNode.
		"""
		
		"""x = DTNode('catX')
		c = DTNode('cat0',{True:x})
		a = DTNode('cat1')
		b = DTNode('cat2',{True:a,False:c})
		print "++++++++++++++++++++++++\n",b.show(""),"\n++++++++++++++++++++++++++++++++++++"""
		
		#for example in examples:
			#print example,"\n\n"
		(allSameClassifiction,sameClassification) = self.check_different_examples(examples)
		# if examples is empty then pick one of two label with same probability
		if not examples:
			if random.random() < 0.5:
				return DTNode(name='cat2')
			else:
				return DTNode(name='cat1')				
		# else if all examples have the same classification then return a Tree whose name is the classification
		elif allSameClassifiction:
			return DTNode(name=sameClassification)
		# else if featureset is empty then return a Tree whose name is the majority label value from the list of labels
		elif not featuresett:
			return DTNode(name = self.majority_label(examples))
		#else # need to expand unlike the above three cases where we return leaf nodes having labels as their name
		else:
			best_fname = self.choose_feature(featuresett,examples)
		 	#tree = DTNode(name = best_fname)
		 	m = self.majority_label(examples)
		# 	apply best_fname feature to all examples and split them into N subsets 
		#			where N is the number of best_fname values in the whole examples
		#			It would be easier to use a dictionary 'sub_examples' of the key:value pair
		#			a best_fname value : a list of examples
		#			so that sub_examples[best_fname value] returns a sub list of examples.
			sub_examples = self.split_examples(best_fname,examples)
		#		for each best_fname value 'fval'
			subtreeTrue = self.decision_tree_learning(sub_examples[True],featuresett)#([best_fname]))
			#print "subtreeTrue",subtreeTrue
		#			assign the subtree to tree.branch[fval]
			#tree.branch[True] = subtree
			subtreeFalse = self.decision_tree_learning(sub_examples[False],featuresett)#([best_fname]))
			#print "subtreeFalse",subtreeFalse
		#			assign the subtree to tree.branch[fval]
			#tree.branch[False] = subtree
		 	return DTNode(best_fname,{True:subtreeTrue,False:subtreeFalse})
		
	"""
		This function takes the best_fname and examples and returns a a dictionary 
		'sub_examples' of the key:value pair a best_fname value : a list of examples.
	"""
	def split_examples(self,best_fname,examples):
		sub_examples = {}
		cat1_list = []
		cat2_list = []
		for ex,label in examples:
			if ex[best_fname]:
				cat1_list.append((ex,label))
			else:
				cat2_list.append((ex,label))
		sub_examples[True] = cat1_list
		sub_examples[False] = cat2_list
		#print "best_fname:",best_fname		
		#print "sub_examples:",sub_examples	
		return sub_examples
	"""
		This function takes a list of examples and returns the label
		that is repeated the most among all the possible labels in the 
		examples' list.
	"""		
	def majority_label(self,examples):
		countLabels = {}
		for ex,label in examples:
			if(not countLabels.has_key(label)):
				countLabels[label] =  1
			else:
				countLabels[label] = countLabels[label]+ 1
		#print countLabels
		#print "majority:",utils.get_maxitem(countLabels)
		return utils.get_maxitem(countLabels)
	"""
		This function takes a list of examples and returns a tuple (Bool,label)
		where Bool tells whethear or not all the examples have the same label.
		If Bool is true, then it makes sense to return what the label is.
		Otherwise, label is not relevant.
	"""			
	def check_different_examples(self,examples):
		labelCheck = ""
		labelCheckTemp = ""
		#print "check_different_examples"
		for ex,label in examples:
			#print label
			if labelCheck == "" and labelCheckTemp == "":
				labelCheck = label
				labelCheckTemp = label
			else:
				labelCheck = label
				if labelCheck != labelCheckTemp:
					return (False,0)
				else:
					labelCheckTemp = labelCheck
		return (True,labelCheck)			
			
	def choose_feature(self,featureset,examples):
		"""
                Implement this for Problem II
                
		Among the given featureset, return the feature that leads to the
		best split among the given list of examples.
		"""
		
		bestAttribute = ""
		attributesTrueCount = {}
		attributesFalseCount = {}
		for f in featureset:
			attributesTrueCount[f] = 0
			attributesFalseCount[f] = 0
			for example,label in examples:
				#print example
				#print f,example[f],label
				if example[f] and label == 'cat1':
					attributesTrueCount[f] = attributesTrueCount[f]+1
				elif not example[f] and label == 'cat2':
					attributesFalseCount[f] = attributesFalseCount[f]+1
		
		#print attributesTrueCount
		#print attributesFalseCount
		
		bestTrue = utils.get_maxitem(attributesTrueCount)
		bestFalse = utils.get_maxitem(attributesFalseCount)
		veryBest = ""
		if(attributesTrueCount[bestTrue]>=attributesFalseCount[bestFalse]):
			veryBest = bestTrue
		else:
			veryBest = bestFalse			

		featureset.remove(veryBest)
		return veryBest

	def test_one(self,features):
		"""
		"""		
		rlabel = self.tree.classify(features)
		return rlabel

########################################################################################
# Third Classifier
########################################################################################
# If you want to change the name of the class
# you also need to change the clasifier selection part (line 70) in the file 'classfiy.py'
class ThirdClassifier():
	"""
		This function takes the featureset and filter out those
		words that are shorter than 2 characters. The point
		is that there is little information gained from a feature
		such as EXIST_in, or EXIST_1. 
		It also truncate the List of features to a maximum of 20 elements.
	"""
	def createSetFeaturesForTree(self,featureset):
		numberOfFeatures = len(featureset)
		listfeaturelist = list(featureset)
		tinyFeatureList = list()
		for t in listfeaturelist:
			if len(t[6:]) > 2: #append to the list only those features with 3 or more characters
				tinyFeatureList.append(t)
		tinyFeatureList = tinyFeatureList[0:min(numberOfFeatures,20)] #truncate the final list to a maximum of 20
		return set(tinyFeatureList)
	"""
        The classifier training process consist in training both
        a NB and DT classifiers for later use.
	"""
	def train(self,examples,featureset):		
		# My classifier uses both NB and Tree Classifier. 
		# I train both classifiers and then test each one separately
		# if the prediction of both agree, return the prediction
		# else, break the tie randomly
		#train NB
		cl = NaiveBayesClassifier()
		cl.train(examples,featureset)
		self.NBClassifier = cl 
		#train DT
		cl = DecisionTreeClassifier()
		cl.train(examples,self.createSetFeaturesForTree(featureset)) #truncate featureset to a size more managable for the tree desicion	
		self.DTClassifier = cl 
		self.weight = 0.5

	"""	a test consist in asking both NB and DT classifier for prediction
		if they both agree, then return the classification. Else, break the tie
		randomly and proportionally to how well the classifiers have behave so far.
	"""
	def test_one(self,features):
		# Test Naive Bayes
		resultNB = self.NBClassifier.test_one(features)
		#print "NB",resultNB
		# Test Tree
		resultDT = self.DTClassifier.test_one(features)
		#print "DT",resultDT
		#If they both agree, return the prediction
		if resultNB == resultDT:
			#print "\t***they agree"
			self.NBPredictor = False
			self.DTPredictor = False
			return resultNB
		#else break the tie randomly and proportional to the results so far
		else:
			if  self.weight < random.random():
				self.NBPredictor = True
				self.DTPredictor = False
				return resultNB
			else:
				self.NBPredictor = False
				self.DTPredictor = True
				return resultDT
	"""	penalize the classfier that made the mistake.
		The penalization consist of lowering the probability
		of using that classifier in the future to break a tie.	
	"""
	def penalize(self,rlabel):
		#print "\t---penalizing... rlabel = ",rlabel
		#print "weight = ",self.weight
		if(self.NBPredictor):
			#print "NBPredictor was used and made a mistake... penalize"
			self.weight = min(self.weight + 0.05,1)
		elif(self.DTPredictor):
			#print "DTPredictor was used and made a mistake... penalize"
			self.weight = max(self.weight - 0.05,0)
		
				
