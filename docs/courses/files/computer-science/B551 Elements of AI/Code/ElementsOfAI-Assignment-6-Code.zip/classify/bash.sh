#!/bin/sh

TRAINING_MAX=1000
FEATURES_MAX=10

for i in {1..5}
do
	python classify.py -c b -q --trmax=$TRAINING_MAX --fsize=$FEATURES_MAX earn acq,crude,gold
done
