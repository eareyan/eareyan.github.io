import game_state
import game_player
import gobblet
import sys
import random
import math

class GobbletPlayer(game_player.GamePlayer):
	def __init__(self, name, gameID):
		game_player.GamePlayer.__init__(self, name, gameID)
		
	# EXAMPLE: Loads a file from the same directory this module is stored in
	#  and returns its contents.  Pattern any file operations you do in your
	#  player on this model.
	#
	# NB: Make a note of the working directory before you cd to the module
	#  directory, and restore it afterward!  The rest of the program may break
	#  otherwise.
	def load_file(self, fname):
		wd = os.getcwd()
		os.chdir("players/gobblet")
		fin = open(fname)
		contents = fin.read()
		fin.close()
		os.chdir(wd)
		return contents
		
	def checkopen(self, state,otherPlayer):
		"Counts the number of openings that could form a victory line"
		c = 0
		#check open main diagonal
		if (state.board_value((0,0)) == None or state.board_value((0,0)).player != otherPlayer)\
				and (state.board_value((1,1)) == None or state.board_value((1,1)).player != otherPlayer)\
				and (state.board_value((2,2)) == None or state.board_value((2,2)).player != otherPlayer):
			c +=1 
		#check open main (inverse) diagonal
		if (state.board_value((0,2)) == None or state.board_value((0,2)).player != otherPlayer)\
				and (state.board_value((1,1)) == None or state.board_value((1,1)).player != otherPlayer)\
				and (state.board_value((2,0)) == None or state.board_value((2,0)).player != otherPlayer):
			c +=1 
		for i in range(3):
			#check every vertical
			if (state.board_value((i,0)) == None or state.board_value((i,0)).player != otherPlayer)\
					and (state.board_value((i,1)) == None or state.board_value((i,1)).player != otherPlayer)\
					and (state.board_value((i,2)) == None or state.board_value((i,2)).player != otherPlayer):
				c +=1 
			#check every horizontal
			if (state.board_value((0,i)) == None or state.board_value((0,i)).player != otherPlayer)\
					and (state.board_value((1,i)) == None or state.board_value((1,i)).player != otherPlayer)\
					and (state.board_value((2,i)) == None or state.board_value((2,i)).player != otherPlayer):
				c +=1 				
		#print state
		#print "otherPlayer:",otherPlayer
		#print "counter:",c
		return c

	def concealed(self, state, player):
		"Counts the number of concealed pieces"
		c = 0
		#loop through the board
		for i in range(3):
			for j in range(3):
				#get all the pieces at position (i,j)
				players = state.board_stack((i,j))
				if(len(players)>1):
					#if there are 2 or more pieces, we remove the last (top-most) piece
					players.pop()
					for k in players:
						if player == k.player:
							#here we have a concealed piece, add 1 to the counter c
							c += 1
						#print k," = ",k.player,",",k.size," concealed at (",i,",",j,")",
					#print ""
					#print state.board_stack((i,j))
		#print "# of concealed pieces = ",c
		return c
		
	def evaluate(self, state):
		"""The evaluate function takes into account various pieces of information to evaluate a state:
			1.- self.checkopen calculate number of openings for opposite player, then add:
			2.- a weighted sum of available pieces, were the weights are a function of the size of the pieces, then take away:
			3.- number of concealed pieces (the idea is that a smaller number of concealed pieces is better for the player) """
			
		"The following are different schemas for the weigths: "
		#weights is a list with the weigts in which each position represent the weight of the corresponding piece
		#this weights give priority to saving the bigger pieces for the end (best so far)
		weights = [1.0,0.5,0.25]
		#this weights give priority to saving the smaller pieces for the end (results in errors more frequently)
		#weights = [0.25,0.5,1]
		#equal weights		
		#weights = [1,1,1]
		#zero weights		
		#weights = [0,0,0]
		
		"Compose all the metrics and calculate the return value f"
		players = state.get_players()
		f = (self.checkopen(state, players[1]) + (weights[0] * state.pieces_available(1,0)) +
												 (weights[1] * state.pieces_available(1,1)) +
												 (weights[2] * state.pieces_available(1,2))
												 - self.concealed(state,players[1])) - (self.checkopen(state, players[0]) + 
												 (weights[0] * state.pieces_available(0,0)) + 
		  										 (weights[1] * state.pieces_available(0,1)) + 
		  										 (weights[2] * state.pieces_available(0,2)) - self.concealed(state,players[0]))
		#print state
		#print "evaluate = ",f
		#sys.exit()
		return f;
	
	# Does most of the terminal checks for a single step in the search
	#
	# state is a GobbletState
	# h is steps to the ply horizon
	# players is the list of valid player IDs
	#
	# Returns None if no termination
	# (value, move) otherwise
	def terminal_checks(self, state, h, players):
		# If first player wins, that's a positive
		if state.is_win(players[0]):
			return (sys.maxint, None)
		# If second player wins, that's a negative
		elif state.is_win(players[1]):
			return (-sys.maxint-1, None)
		
		# If there are no more expansions allowed, or if
		# we hit the horizon, evaluate	
# 		if state.expansions_count() <= 0:
# 			print "there are no more expansions allowed"	
		if state.expansions_count() <= 0 or h <= 0:
			return (self.evaluate(state), None)
		
		# if no termination, return None
		return None
		
	
	# A helper function for minimax_move().  This one returns a
	# (value, move) tuple that lets us back values up the tree and still
	# return a move at the top.
	#
	# state is a GobbletState
	# h is an integer representing the distance to the ply horizon
	def minimax_search(self, state, h):
	
		# Get player IDs
		players = state.get_players()
		
		# Do most of our terminal checks
		term = self.terminal_checks(state, h, players)
		if term != None:
			return term
		
		# Get successor states
		# We should check to see if this is None, but since we just
		#  checked to see if expansion_count was <= 0, we're safe
 		successors = state.successors()
		# If there are no successors and nobody's won, it's a draw
		if len(successors) == 0:
			return (0, None)
		
		# Recur on each of the successor states (note we take the state out
		# of the successor tuple with x[1] and decrease the horizon)
		values = [self.minimax_search(s.state, h-1) for s in successors]
		# We're not interested in the moves made, just the minimax values
		values = [x[0] for x in values]
		# Look for the best among the returned values
		# Max if we're player 1
		# Min if we're player 2
		if state.get_next_player() == players[0]:
			max_idx = max(enumerate(values), key=lambda x: x[1])[0]
		else:
			max_idx = min(enumerate(values), key=lambda x: x[1])[0]
		# Return the minimax value and corresponding move
		return (values[max_idx], successors[max_idx].move)
	

	# Get a move for the indicated state, using a minimax search.
	#
	# "state" is still a GobbletState object
	def minimax_move(self, state, visited):
		# Adjust our ply horizon to the expansion count,
		# based on a maximum branching factor of 30.
		exp = state.expansions_count()
		h = int(math.floor(float(exp) ** (1.0 / 15)))
		#h = 3
		print "minimax_move h = ",h
		#print "Valor de h para minimax_move: ",h
		return self.minimax_search(state,h)[1]
	
	# Get a move for the indicated state, using an alpha-beta search.
	#
	# state is a TicTacToeState
	def alpha_beta_move(self, state, visited):
		# Adjust our ply horizon to the expansion count,
		# based on an average branching factor of 4.
		exp = state.expansions_count()
		h = int(math.floor(float(exp) ** (1.0 / 10)))
		print "alpha_beta_move h = ",h
		#print "Valor de h para alpha_beta_move: ",h		
		return self.alpha_beta_search(state, h, -sys.maxint-1, sys.maxint)[1]
		
		
	# A helper function for alpha_beta_move().  See minimax_search().
	#
	# a,b are alpha, beta values.
	def alpha_beta_search(self, state, h, a, b):
		# Get player IDs
		players = state.get_players()
		player = state.get_next_player()
		
		# Do most of our terminal checks
		term = self.terminal_checks(state, h, players)
		if term != None:
			return term
		
		# Get successor states
		# We should check to see if this is None, but since we just
		#  checked to see if expansion_count was <= 0, we're safe
		successors = state.successors()
		# If there are no successors and nobody's won, it's a draw
		if len(successors) == 0:
			return (0, None)
		
		# We start out with a low best-value and no move
		v = -sys.maxint-1 if player == players[0] else sys.maxint
		m = None
		for s in successors:
			# Recur on the successor state
			s_val = self.alpha_beta_search(s.state, h-1, a, b)
			# If our new value is better than our best value, update the best
			#  value and the best move
			if (player == players[0] and s_val[0] > v) \
					or (player == players[1] and s_val[0] < v):
				v = s_val[0]
				m = s.move
			# If we're maxing and exceeding the min above, just return
			# Likewise if we're minning and exceeding the max above
			if (player == players[0] and v >= b) \
					or (player == players[1] and v <= a):
				return (v, m)
			# Update a,b for the next successor
			a = a if player == players[1] else max(a,v)
			b = b if player == players[0] else min(b,v)
		# return the best value, move we found
		return (v,m)
				
	def tournament_move(self, state, visited):
		return self.alpha_beta_move(state, visited)		
		
def make_player(name, gameID):
	return GobbletPlayer(name, gameID)