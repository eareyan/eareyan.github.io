#!/usr/bin/env python

import bayesnet
import politics

def p1():
        pass
	
def p2():
        pass
	
def p3():
        pass														{'Vote': 'D',
														'Ideology': 'P'})
	
def p4():
	pass
	
def main():
	p1()
	p2()
	p3()
	p4()
	
	
if __name__ == "__main__":
	main()
