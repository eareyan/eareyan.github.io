import math

D = [(2,1),(4,7),(5,6), (6,8), (7,8)]

def model(theta,x):
    return math.log(theta*x)

def modeldtheta(theta,x):
    return 1.0/theta


def E(theta):
    return sum(pow(model(theta,x)-y,2.0) for x,y in D)

def dE(theta):
    return 2.0*sum(modeldtheta(theta,x)*(model(theta,x)-y) for x,y in D)

def gradientDescent(theta0,alpha,iters):
	x_old = 0
	x_new = theta0
	for i in range(iters):
		x_old = x_new
		x_new = x_old - alpha * dE(x_new)
	return x_new

theta = gradientDescent(50,1.0,1000)

print "Optimized theta:",theta
print "E(theta):",E(theta)
print "dE(theta):",dE(theta)
print "Predictions:"
print [(x,model(theta,x)) for (x,y) in D]
