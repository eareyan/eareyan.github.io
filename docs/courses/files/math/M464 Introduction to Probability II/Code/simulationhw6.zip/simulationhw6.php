<?php

function random_float ($min,$max) {
   return ($min+lcg_value()*(abs($max-$min)));
}

$p = (2/3);
$current_state = "C";
$getwet = 0;
$iterations = 99999;
for($i=0;$i<$iterations;$i++){
	if($current_state == "C"){
		if(random_float(0,1) < $p){ //It rains
			//Stay in state C
		}else{ //It does not rain
			$current_state = "NC"; //walk
		}
	}else if($current_state == "NC"){
		if(random_float(0,1) < $p){ //It rains
			$getwet ++;
		}else{ //It does not rain
			//Nothing happens
		}
		$current_state = "C"; //In any case from NC move to C
	}
}
echo "<h1>One Car probbility of rain = $p</h1>";
echo "(Teo ) Probability of getting wet: " . (2*$p*(1-$p))/(2-$p) . "<br/>";
echo "(Sim ) Probability of getting wet: " . ($getwet/($iterations/2));


$p = (2/3);
$current_state = "2";
$getwet = 0;
$iterations = 99999;
for($i=0;$i<$iterations;$i++){
	if($current_state == "2"){
		if(random_float(0,1) < $p){ //It rains
			$current_state = "1";
		}else{ //It does not rain
			$current_state = "0"; //walk
		}
	}else if($current_state == "1"){
		if(random_float(0,1) < $p){ //It rains
			$current_state = "2";
		}else{ //It does not rain
			//Nothing happens
		}
	}else if($current_state == "0"){
		if(random_float(0,1) < $p){ //It rains
			$getwet ++;
		}
		$current_state = "2";		
	}
}
echo "<h1>Two Cars probability of rain = $p</h1>";
echo "(Teo ) Probability of getting wet: " . (2*$p*(1-$p))/(3-$p) . "<br/>";
echo "(Sim ) Probability of getting wet: " . ($getwet/($iterations/2));

	