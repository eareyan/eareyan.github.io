<?php


echo "<h3>Exersice 2 Puzzle</h3>";
/* Mirrors */
function r1(array $v){
	return array(-$v[0],-$v[1]);
}
function r2(array $v){
	return array(2-$v[0],-2-$v[1]);
}
function r3(array $v){
	return array(-4-$v[0],2-$v[1]);
}

echo "r1:"; 	print_r(r1(array(1,0)));
echo "<br/>r2:";print_r(r2(array(1,0)));
echo "<br/>r3:";print_r(r3(array(1,0)));

echo "<h4>One solution is: r1r2r1r2r1r3</h4>";
print_r(r1(r2(r1(r2(r1(r3(array(1,0))))))));
echo "<h4>Another solution is: r1r3r1r2r1r2</h4>";
print_r(r1(r3(r1(r2(r1(r2(array(1,0))))))));
echo "<br/>";

/*Try to find as many solutions using only 6 transformations as possible*/
$solutions = array();
while(true){
	$shortsolution = false;
	$maxwordlenght = 12;
	while(!$shortsolution){
		$sol = false;
		$v = array(1,0);
		$word = '';
		while(!$sol && strlen($word)<=$maxwordlenght){
			
			$i = rand(1,3);
			$word = 'r'.$i.$word;
			$v = call_user_func('r'.$i,$v);
			
			if($v[0] == 1 && $v[1] == 2){
				$sol = true;
			}
		}
		if(strlen($word)>$maxwordlenght){
			//echo "No short solution found";
		}else{
			echo "<h4>Short Solution is: $word</h4>";
			$shortsolution = true;
		}
	}
	if(!in_array($word,$solutions)){
		$solutions[] = $word;
	}
	echo "<h2>Solutions so far:";
	print_r($solutions);
	echo "</h2>";
}

/*Solutions with only 6 moves found so far:
r1r2r1r2r1r3 -- given
r1r3r1r2r1r2
r1r2r1r3r1r2
*/