<?php
/*
* This program simulates the Markov Chain in the following exercise:
*
*	An unfair coin with Pr[H] = .4 is flipped repeatedly, and the result of each flip is noted.
*	Find the expected number of flips before there are three consecutive heads for the first time. 
*/
$number_iteration = 100000;
$total = 0;
for($i=0;$i<$number_iteration;$i++){
	
	$current_state = 0;
	$counter = 0;
	
	while($current_state!=4){
		$counter++;	
		switch($current_state){
			case 0:
				if( (mt_rand() / mt_getrandmax()) <= .4){
					$current_state = 1;
				}else{
					$current_state = 2;
				}
				break;
			case 1:
				if( (mt_rand() / mt_getrandmax()) <= .4){
					$current_state = 3;
				}else{
					$current_state = 2;
				}
				break;
			case 2:
				if( (mt_rand() / mt_getrandmax()) <= .4){
					$current_state = 1;
				}
				break;
			case 3:
				if( (mt_rand() / mt_getrandmax()) <= .4){
					$current_state = 4;
				}else{
					$current_state = 2;
				}
		}
	}
	//echo "It took $counter  times <br/>";
	$current_state = 0;
	$total += $counter;
	$counter = 0;
}
$average = $total / $number_iteration;
echo "<h2>Average is: $average</h1>";