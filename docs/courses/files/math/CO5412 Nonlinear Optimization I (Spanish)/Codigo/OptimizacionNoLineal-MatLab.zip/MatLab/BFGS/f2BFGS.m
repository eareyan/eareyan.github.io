classdef f2BFGS < BFGS
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function obj = f2BFGS(arg)
              obj = obj@BFGS(arg);
              obj.xmin = [2;1];
              obj.statfilename = 'f_2BFGS';
        end
        function [ret]=f(obj,arg)
            ret = (arg(1)-2)^4+(arg(1)-2*arg(2))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 4*(arg(1)-2)^3+2*(arg(1)-2*arg(2));
            fd_y = -4*(arg(1)-2*arg(2));
        end
    end
end

