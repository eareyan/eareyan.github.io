clc

f = inline('x^2-3*x');

a = 0.5;
b = 2;

a_k = a;
b_k = b;
alfa=(sqrt(5)-1)/2;
%epsilon=0.2;
epsilon=0.0001;
%a=input('Mensaje')
k=0;
parar = false;

fprintf('==============================\n==METODO DE LA SECCIONAUREA==\n==============================\n');
fprintf('Los siguientes son los parametros utilizados:\n a_k=%f, b_k=%f, alfa=%f, epsilon=%f\n',a_k, b_k, alfa,epsilon);
fprintf('\nComienza la iteracion para k=%d\n',k);

while (~parar)
    distancia = abs(b_k-a_k);
    fprintf('\nk=%d\n\t%f < %f ?',k,distancia,epsilon);
    if(distancia<epsilon)
        parar = true;
    else
        lambda_k=a_k+(1-alfa)*(b_k-a_k);
        miu_k=a_k+alfa*(b_k-a_k);
        fprintf('\n\t\tlambda_k = %f\t==> f(lambda_k) = %f' , lambda_k, f(lambda_k));
        fprintf('\n\t\tmiu_k = %f\t==> f(miu_k) = %f' , miu_k, f(miu_k));
        if f(lambda_k)>f(miu_k)
            a_k=lambda_k;
            lambda_k=miu_k;
        else
            b_k=miu_k;
            miu_k=lambda_k;
        end
        fprintf('\n\n\t\tNuevo intervalo:\n\t\ta_k = %f, b_k = %f',a_k,b_k);
    end
    k=k+1;
end
fprintf('\n\n===> Termino el metodo:\n a_k = %f, b_k = %f\nf(a_k) = %f, f(b_k) = %f\n',a_k,b_k,f(a_k),f(b_k));
fprintf('\nMinimo aprox. =%f\n',(a_k+b_k)/2);

