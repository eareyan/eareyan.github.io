


p= [1 1 0];
x= linspace(-20,20);
y=polyval(p,x);
plot (x,y);

%{
p= [-4 3 2 0];
x= linspace(-2,2);
y=polyval(p,x);
plot (x,y);


x = -pi:.1:pi;
y = sin(x)-cos(2*x);
plot(x,y)


x = -5*pi:.1:5*pi;
y = cos(x)+2*sin(2*x);
plot(x,y)



p= [1 0 -1];
x= linspace(-2.75,2.75);
y=polyval(p,x);
plot (x,y);
p= [1 -2 1];
x= linspace(-2.75,2.75);
y=polyval(p,x);
plot (x,y);


[x,y]=meshgrid(-10:0.25:10,-10:0.25:10);
surf(x,y,2*x.^2+2*x*y-0.5*y.^2-x-3*y)
  
[x,y]=meshgrid(-1:0.25:1,-1:0.25:1);
surf(x,y,100*(y-x^.2).^2+(1-x).^2)
  
[x,y]=meshgrid(-1:0.025:1,-1:0.025:1);
surf(x,y,3*x.^2+2*x*y+y.^2)

[x,y]=meshgrid(-3:0.5:3,-3:0.5:3);
surf(x,y,1/2*((x.^2-y)*(x.^2-y) + (1-x)*(1-x)))
%}
