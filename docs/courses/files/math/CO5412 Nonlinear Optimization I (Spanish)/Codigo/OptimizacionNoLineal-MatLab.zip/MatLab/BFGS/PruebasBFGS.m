clear
clc

f1 = f1BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf1] = f1.metodobfgs([1;1])

f2 = f2BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf2] = f2.metodobfgs([3;0])
%[xf2] = f2.metodonewtonmodificado([0;10])

f3 = f3BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf3] = f3.metodobfgs([0;0])
