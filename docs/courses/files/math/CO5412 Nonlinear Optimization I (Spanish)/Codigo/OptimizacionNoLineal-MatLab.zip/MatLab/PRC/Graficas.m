clear
clc

x=linspace(-10,10,25);
y=linspace(-10,10,25);
[x,y] = meshgrid(x,y);
%Graficar el objeto
f1 = f1RegionConfianza([]);
for i=1:length(x)
    for j=1:length(y)
        z(i,j) = f1.aprox_cuadratica([0;-1],[x(i,j);y(i,j)]);
        %z(i,j) = f1.aprox_cuadratica([0;0.5],[x(i,j);y(i,j)]);
    end
end

contour(x,y,z,30)
%mesh(x,y,z)