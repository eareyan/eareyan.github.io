classdef f1RegionConfianza < RegionConfianza
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function [d_x,d_y] = d(obj,arg)
        end
        function obj = f1RegionConfianza(arg)
              obj = obj@RegionConfianza(arg);
              obj.xmin = [0;0];
              obj.statfilename = 'f_1RegionConfianza';
        end
        function [ret]=f(obj,arg)
            ret = 10*(arg(2)-arg(1)*arg(1))^2+(1-arg(1))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = -40*arg(1)*arg(2)+40*arg(1)^3-2+2*arg(1);
            fd_y = 20*arg(2)-20*arg(1)*arg(1);
        end
        function H = hessiano(obj,arg)
            H = [-40*arg(2)+120*arg(1)^2+2,-40*arg(1);-40*arg(1),20];
        end
    end
end

