classdef GradienteEspectral
    properties
        n
        xmin
        statfilename
    end
    methods(Abstract)
        [ret] = hessiano(x)
        [ret] = f(obj,arg)
        [ret] = grad(obj,arg)
    end
    methods
        function obj = GradienteEspectral(arg)
        end
        function [ret] = norma(obj,x)
            ret = 0;
            for i=1:obj.n
                ret = ret + x(i)*x(i);
            end
        end
        function [ret]=metodogradienteespectral(obj,xk)       
            parar = false;
            k=0;
            alpha = 1.5;
            
            fid_tex = fopen(strcat('stats',obj.statfilename,'-',int2str(obj.n),'-','.tex'),'w');
            fprintf(fid_tex,'\\begin{tabular}{|c|c|c|c|c|}\\hline\n\t$k$&$||x_k-x_*||$\\\\ \\hline');
            
            while ~parar
                %Calcular el grad para usarlo como condicion de parada
                normagrad = obj.norma(xk - obj.xmin);
                fprintf(fid_tex,'\n\t%d&%f\\\\ \\hline',k,normagrad);                
                %Se encontro la solucion 
                if normagrad < 10^-14
                    parar = true;
                else
                %Aun no se encontro, realizar otra iteracion
                    g = obj.grad(xk);                
                    d = (-1 * g) / alpha;
                    xk = xk+d;
                    g_s = obj.grad(xk);
                    y = g_s - g;
                    alpha = (d'*y)/(d'*d);
                    k = k+1;
                end 
                if(k>500)
                    parar = true;
                end
            end
            ret = xk;
            fprintf(fid_tex,'\n\\end{tabular}\\\\\\\\');            
            fclose(fid_tex);            
        end
    end 
end