clear
clc

%f1 = f1RegionConfianza([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[x] = f1.metodoregionconfianza([1.2;1.2])
%[x] = f1.metodoregionconfianza([-1.2;1])
%[xf1] = f1.metododogleg([1.2;1.2],1)
%[xf1] = f1.metododogleg([-1.2;1],1)

f2 = f2RegionConfianza([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[x] = f2.metodoregionconfianza([1.2;1.2])
%[x] = f2.metodoregionconfianza([-1.2;1])
[xf1] = f2.metododogleg([1.2;1.2],1)
[xf1] = f2.metododogleg([-1.2;1],1)
