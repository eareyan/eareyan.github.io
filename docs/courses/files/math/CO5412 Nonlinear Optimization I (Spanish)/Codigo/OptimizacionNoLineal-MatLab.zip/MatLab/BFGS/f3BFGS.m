classdef f3BFGS < BFGS
    % Funcion particular
    %   Implementa la funcion 3 de la tarea 4
    
    properties
    end
    methods
        function obj = f3BFGS(arg)
              obj = obj@BFGS(arg);
              obj.xmin = [0.695884443763468;-1.347942221881734];
              obj.statfilename = 'f_3BFGS';
        end
        function [ret]=f(obj,arg)
            ret = arg(1)^4+arg(1)*arg(2)+(1+arg(2))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 4*arg(1)^3+arg(2);
            fd_y = arg(1)+2*arg(2)+2;
        end
    end
end

