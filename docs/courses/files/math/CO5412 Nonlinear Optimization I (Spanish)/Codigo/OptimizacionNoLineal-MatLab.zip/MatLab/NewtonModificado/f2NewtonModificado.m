classdef f2NewtonModificado < NewtonModificado
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function obj = f2NewtonModificado(arg)
              obj = obj@NewtonModificado(arg);
              obj.xmin = [2;1];
              obj.statfilename = 'f_2NewtonModificado';
        end
        function [ret]=f(obj,arg)
            ret = (arg(1)-2)^4+(arg(1)-2*arg(2))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 4*(arg(1)-2)^3+2*(arg(1)-2*arg(2));
            fd_y = -4*(arg(1)-2*arg(2));
        end
        function H = hessiano(obj,arg)
            %El hessiano inverso es H = [1/4,-1/4;-1/4,3/4]
            H = [12*(arg(1)-2)^2+2,-4;-4,8];
        end
    end
end

