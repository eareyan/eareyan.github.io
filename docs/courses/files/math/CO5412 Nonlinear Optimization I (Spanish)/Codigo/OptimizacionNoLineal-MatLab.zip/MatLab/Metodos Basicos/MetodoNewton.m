clc

%f    = inline('-(1.4)*x^4+(1/3)*x^3+x^2');
%f_d  = inline('-4*x^3+3*x^2+2*x');
%f_d2 = inline('-12*x^2+6*x+2');

%f    = inline('sin(x)-cos(2*x)');
%f_d  = inline('cos(x)+2*sin(2*x)');
%f_d2 = inline('-sin(x)+4*cos(2*x)');

%f    = inline('(1/3)*x^3-x');
%f_d  = inline('x^2-1');
%f_d2 = inline('2*x');

%f    = inline('(1/3)*x^3-x^2+1');
f_d  = inline('x^2-2*x+1');
f_d2 = inline('2*x-2');

x_0 = 0.5;
x_k=x_0;

epsilon=10^-5;
k=0;
parar = false;

fprintf('==============================\n==METODO DE NEWTON==\n==============================\n');
fprintf('Los siguientes son los parametros utilizados:\n x_0=%f, epsilon=%f\n',x_0,epsilon);
while (~parar)
    criterio_parada = abs(f_d(x_k));
    fprintf('\nk=%d\n\t%f < %f ? x_k = %f',k,criterio_parada,epsilon,x_k);
    if(criterio_parada <epsilon)
        parar=true;
    else
        x_k = x_k-(f_d(x_k)/f_d2(x_k));
        k=k+1;
    end;
end
fprintf('\n\n===> Termino el metodo:');
fprintf('\nMinimo aprox. =%f\n',x_k);