classdef f4 < GradienteBLI
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function obj = f4(arg)
              obj = obj@GradienteBLI(arg);
              obj.xmin = [1;1];
              obj.statfilename = 'f_4GradienteBLI';
        end
        function [ret]=f(obj,arg)
            ret = 100*(arg(2)-arg(1)*arg(1))^2+(1-arg(1))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = -400*arg(1)*arg(2)+400*arg(1)^3-2+2*arg(1);
            fd_y = 200*arg(2)-200*arg(1)*arg(1);
        end
    end
end

