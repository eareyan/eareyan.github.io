clear
clc

% BFGS

%f1 = f1BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf1] = f1.metodobfgs([1;1])

%f2 = f2BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodobfgs([3;0])
%[xf2] = f2.metodobfgs([0;10])

%f3 = f3BFGS([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf3] = f3.metodobfgs([0;0])


% Newton Modificado
%f1 = f1NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf1] = f1.metodonewtonmodificado([1;1])

%f2 = f2NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodonewtonmodificado([3;0])
%[xf2] = f2.metodonewtonmodificado([0;10])

%f3 = f3NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf3] = f3.metodonewtonmodificado([0;0])

% Newton
%f1 = f1Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf1] = f1.metodonewton([1;1]);

%f2 = f2Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodonewton([3;0]);
%[xf2] = f2.metodonewton([0;10]);

%f3 = f3Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f3.metodonewton([0;0]);



tic;
%Gradiente Conjugado, Espectral y BLE
f1 = f1GradienteConjugado(100);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteconjugado(xk)

clear

f1 = f1GradienteConjugado(200);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteconjugado(xk)

clear

f1 = f1GradienteConjugado(500);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteconjugado(xk)

clear

f1 = f1GradienteEspectral(100);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteespectral(xk)

clear

f1 = f1GradienteEspectral(200);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteespectral(xk)

clear

f1 = f1GradienteEspectral(500);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteespectral(xk)

clear

f1 = f1GradienteBLE(100);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteble(xk)

clear

f1 = f1GradienteBLE(200);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteble(xk)

clear

f1 = f1GradienteBLE(500);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteble(xk)
toc;