clc

%f = inline('-(1.4)*x^4+(1/3)*x^3+x^2');
%f_d = inline('-4*x^3+3*x^2+2*x');

%f = inline('sin(x)-cos(2*x)');
f_d = inline('cos(x)+2*sin(2*x)');


x_0 = 0;
x_1 = x_0 + 10^-5; %Punto muy cercano al anterior

x_k  = x_1;
x_k_1 = x_0;

epsilon=10^-5;
k=0;
parar = false;

fprintf('==============================\n==METODO SECANTE==\n==============================\n');
fprintf('Los siguientes son los parametros utilizados:\n x_0=%f, epsilon=%f\n',x_0,epsilon);
while (~parar)
    criterio_parada = abs(f_d(x_k));
    fprintf('\nk=%d\n\t%f < %f ? x_k = %f',k,criterio_parada,epsilon,x_k);
    if(criterio_parada <epsilon)
        parar=true;
    else
        x_k1 = x_k-(f_d(x_k)*((x_k-x_k_1)/(f_d(x_k)-f_d(x_k_1))));
        x_k_1= x_k;
        x_k  = x_k1;
    end;
    k=k+1;
end
fprintf('\n\n===> Termino el metodo:');
fprintf('\nMinimo aprox. =%f\n',x_k);
