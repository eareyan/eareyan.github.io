clear
clc

%f1 = f1([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf1] = f1.metodogradiente([1;1])

%f1 = f1([0.00001;0.75]); %el primer parametro es eta y el segundo ro
%[xf1] = f1.metodogradiente([1;1])

%f2 = f2([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodogradiente([2;2])

%f3 = f3([0.01;0.001]); %el primer parametro es eta y el segundo ro
%[xf3] = f3.metodogradiente([1.2;1.2])

%f3 = f3([0.01;0.001]); %el primer parametro es eta y el segundo ro
%[xf3] = f3.metodogradiente([-1.2;1])

f4 = f4([0.01;0.001]); %el primer parametro es eta y el segundo ro
[xf3] = f4.metodogradiente([-1.2;1])