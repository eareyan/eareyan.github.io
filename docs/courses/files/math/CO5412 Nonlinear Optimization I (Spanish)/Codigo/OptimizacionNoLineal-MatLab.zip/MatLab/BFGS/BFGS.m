classdef BFGS < Newton
    properties
        H = [1,0;0,1];
    end
    methods
        function dummy=hessiano(arg) end
        
        function obj = BFGS(arg)
            obj = obj@Newton(arg);
        end
        function [d_x,d_y] = d(obj,arg)
            [g1,g2] = obj.grad_f(arg);
            g = [g1;g2];
            d = -1* (obj.H \ g);
            d_x = d(1);
            d_y = d(2);
        end
        function [ret] = metodobfgs(obj,xk)
            parar = false;
            k=0;
            fid = fopen(strcat('stats',obj.statfilename,'.txt'),'w');
            fprintf(fid,'k\tkx\t||xk-xmin||\t||grad_f(xk)||\tRecortes\n');
            
            fid_tex = fopen(strcat('stats',obj.statfilename,'.tex'),'w');
            fprintf(fid_tex,'\\underline{Funcion:} $%s$ \\\\ \nParametros: $\\eta = %f; \\rho = %f; x_0 = (%f;%f)$; $x_*=(%f,%f)$ \\\\ \n',obj.statfilename,obj.eta,obj.ro,xk(1),xk(2),obj.xmin(1),obj.xmin(2));
            fprintf(fid_tex,'\\begin{tabular}{|c|c|c|c|c|}\\hline\n\t$k$&$x_k$&$||x_k-x_*||$&$||grad_f(x_k)||$&$recortes$\\\\ \\hline');
            
            recortes = 0;
            while ~parar
                [g1,g2] = obj.grad_f(xk);
                g = [g1;g2];
                normagrad = obj.norma([g1;g2]);
                fprintf(fid,'%d\t(%f,%f)\t%f\t%f\t%f\n',k,xk(1),xk(2),obj.norma(xk-obj.xmin),normagrad,recortes);                
                fprintf(fid_tex,'\n\t%d&(%f,%f)&%f&%f&%d\\\\ \\hline',k,xk(1),xk(2),obj.norma(xk-obj.xmin),normagrad,recortes);
                if normagrad < 10^-5 %condicion de terminacion del algoritmos
                    parar = true;
                else
                    [dx,dy] = obj.d(xk);
                    dk = [dx;dy];
                    %if(g' * dk>=0)
                    %    fprintf('No es de descenso');
                    %end
                    [lambda,recortes]  = obj.backtracking(xk); % = 1; %
                    xk = xk + lambda * dk;
                    [gx,gy] = obj.grad_f(xk);
                    g_1 = [gx;gy];         
                    y = g_1 - g;
                    obj.H = obj.H + ((y*y')/(y'*y)) - ((obj.H*dk)*(obj.H*dk)'/(dk'*obj.H*dk));
                end
                k = k+1;
                if(k>1000)
                    parar = true;
                end
            end
            ret = xk;
            fclose(fid);
            fprintf(fid_tex,'\n\\end{tabular}\\\\\\\\');            
            fclose(fid_tex);            
        end
    end
end