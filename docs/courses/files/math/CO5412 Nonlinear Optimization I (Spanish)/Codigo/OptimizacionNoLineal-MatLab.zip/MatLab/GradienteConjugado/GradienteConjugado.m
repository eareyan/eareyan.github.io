classdef GradienteConjugado
    properties
        n
        xmin
        statfilename
    end
    methods(Abstract)
        [ret] = hessiano(x)
        [ret] = f(obj,arg)
        [ret] = grad(obj,arg)
    end
    methods
        function obj = GradienteConjugado(arg)
        end
        function [ret] = norma(obj,x)
            ret = 0;
            for i=1:obj.n
                ret = ret + x(i)*x(i);
            end
        end
        function [ret]=metodogradienteconjugado(obj,xk)       
            parar = false;
            k=0;
            beta = 0;
            d = 0;
            
            fid_tex = fopen(strcat('stats',obj.statfilename,'-',int2str(obj.n),'-','.tex'),'w');
            fprintf(fid_tex,'\\begin{tabular}{|c|c|c|c|c|}\\hline\n\t$k$&$||x_k-x_*||$\\\\ \\hline');
            
            while ~parar
                %Calcular el grad para usarlo como condicion de parada
                normagrad = obj.norma(xk - obj.xmin);
                fprintf(fid_tex,'\n\t%d&%f\\\\ \\hline',k,normagrad);                
                %Se encontro la solucion 
                if normagrad < 10^-14
                    parar = true;
                else
                %Aun no se encontro, realizar otra iteracion
                    g = obj.grad(xk);
                    d = (-1 * g) + beta*d;
                    alpha = ((-1 * g)'*d)/(d'*obj.hessiano*d);
                    xk = xk+alpha*d;
                    g = obj.grad(xk);
                    beta = (g'*obj.hessiano*d) / (d'*obj.hessiano*d);
                    k = k+1;
                end 
                if(k>250)
                    parar = true;
                end
            end
            ret = xk;
            fprintf(fid_tex,'\n\\end{tabular}\\\\\\\\');            
            fclose(fid_tex);            
        end
    end 
end