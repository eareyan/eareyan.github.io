clear
clc

%f1 = f1NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf1] = f1.metodonewtonmodificado([1;1])

%f2 = f2NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodonewtonmodificado([3;0])
%[xf2] = f2.metodonewtonmodificado([0;10])

%f3 = f3NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf3] = f3.metodonewtonmodificado([0;0])

f4 = f4NewtonModificado([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf4] = f4.metodonewtonmodificado([-1.2;1])
