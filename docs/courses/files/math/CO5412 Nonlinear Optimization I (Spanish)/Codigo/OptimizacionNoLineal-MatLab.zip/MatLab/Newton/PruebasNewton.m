clear
clc

f1 = f1Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf1] = f1.metodonewton([1;1]);

f2 = f2Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf2] = f2.metodonewton([3;0]);

%f2 = f2Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
%[xf2] = f2.metodonewton([0;10]);

f3 = f3Newton([]); %sin parametros toma los valores por defecto, eta = 10^-4 y ro = 1/2
[xf2] = f3.metodonewton([0;0]);