
%{
x=0.5:0.01:2;
y=x.^2-3*x;
plot(x,y);
%}


clc

f = inline('x^2-3*x');
f_d = inline('2*x-3');

a = 0.5;
b = 2;
a_k = a;
b_k = b;
%epsilon=0.2;
epsilon=0.0001;
k=0;
parar = false;

fprintf('==============================\n==METODO DE BISECCION==\n==============================\n');
fprintf('Los siguientes son los parametros utilizados:\n a_k=%f, b_k=%f epsilon=%f\n',a_k, b_k,epsilon);
fprintf('\nComienza la iteracion para k=%d\n',k);

%if(f_d(a)<0 & f_d(b)<0)
    

while (~parar)
    distancia = abs(b_k-a_k);
    fprintf('\nk=%d\n\t%f < %f ?',k,distancia,epsilon);
    fprintf('\n\ta_k = %f, b_k = %f',a_k,b_k);
    if(distancia<epsilon)
        parar = true;
    else
        medio = (a_k+b_k)/2;
        medio_f = f_d(medio);
        fprintf('\n\tmedio=%f,f_d(medio)=%f',medio,medio_f);
        if(medio_f<0 & f_d(a_k)<0)
            a_k=medio;
        elseif(medio_f<0 & f_d(b_k)<0)
            b_k=medio;
        elseif(medio_f>0 & f_d(a_k)>0)
            a_k=medio;
        elseif(medio_f>0 & f_d(b_k)>0)
            b_k=medio;
        end;
        fprintf('\n\ta_k=%f,b_k=%f\n\tf_d(a_k)=%f,f_d(b_k)=%f',a_k,b_k,f_d(a_k),f_d(b_k));
    end;
    k=k+1;
end
fprintf('\n\ta_k=%f,b_k=%f\n\tf_d(a_k)=%f,f_d(b_k)=%f',a_k,b_k,f_d(a_k),f_d(b_k));
fprintf('\n\n===> Termino el metodo:\n\nMinimo aprox. =%f\n',(a_k+b_k)/2);
