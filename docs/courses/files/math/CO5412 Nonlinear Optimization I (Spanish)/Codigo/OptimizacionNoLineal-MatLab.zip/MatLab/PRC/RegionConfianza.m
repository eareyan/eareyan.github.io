classdef RegionConfianza < Base
    properties
    end
    methods
        function [ret] = aprox_cuadratica(obj,x,s)
            f = obj.f(x);
            [g1,g2] = obj.grad_f(x);
            g = [g1;g2];
            h = obj.hessiano(x);
            ret = f + g'*s+0.5*(s'*h*s);
        end        
        function obj = RegionConfianza(arg)
            obj = obj@Base(arg);
        end        
        function [d_x,d_y] = d(obj,arg) 
            %Definicion Dummy%
        end
        function [ret] = metodoregionconfianza(obj,x)
            delta_barra = 100;
            eta = 1/8;
            %Para establecer el delta_0 resuelvo el PRC y busco la norma
            s = obj.metododogleg(x,1)            
            delta = obj.norma(s);
            parar = false;
            k=0;
            
            fid_tex = fopen(strcat('stats',obj.statfilename,'.tex'),'w');
            fprintf(fid_tex,'\\begin{tabular}{|c|c|c|c|}\\hline\n\t$k$&$x_k$&$||x_k-x_*||$&$||grad_f(x_k)||$\\\\ \\hline');
            
            while ~parar
                [g1,g2] = obj.grad_f(x);
                normagrad = obj.norma([g1;g2]);
                fprintf(fid_tex,'\n\t%d&(%f,%f)&%f&%f\\\\ \\hline',k,x(1),x(2),obj.norma(x-obj.xmin),normagrad);                
                if normagrad < 10^-5 %condicion de terminacion del algoritmo
                    parar = true;
                else
                    %(1) Obtener Sx como solucion de PRC (sol. aprox). Usa dogleg.
                    s = obj.metododogleg(x,delta);
                    %(2) Evaluo que tan buena es la aprox. cuadratica
                    ro = (obj.f(x) - obj.f(x+s))/(obj.aprox_cuadratica(x,[0;0]) - obj.aprox_cuadratica(x,s));
                    %(3) Decision segun el valor de ro
                    if ro < 0.25
                        delta = 0.25 * obj.norma(s);
                    elseif (ro > 0.75) && (obj.norma(s) == delta)
                        delta = min(2*delta,delta_barra);                 
                    end
                    %(4) Confio en la region y actualizo el proximo iterado
                    if ro > eta
                        x = x + s;
                    end
                    k = k+1;
                end
                if(k>1000)
                    parar = true;
                end                
            end
            fprintf(fid_tex,'\n\\end{tabular}\\\\\\\\');            
            fclose(fid_tex);            
            ret = x;
        end
    end
end