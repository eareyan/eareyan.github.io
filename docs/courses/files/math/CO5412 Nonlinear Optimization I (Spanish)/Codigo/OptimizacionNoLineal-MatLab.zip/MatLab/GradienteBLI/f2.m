classdef f2 < GradienteBLI
    % Funcion particular
    %   Implementa la funcion 2 de la tarea.
    
    properties
    end
    methods
        function obj = f2(arg)
              obj = obj@GradienteBLI(arg);
              obj.xmin = [1;1];
              obj.statfilename = 'f_2';
         end        
        function [ret]=f(obj,arg)
            ret = 1/2*(arg(1)^4-2*arg(1)^2*arg(2)+arg(2)^2+1-2*arg(1)+arg(1)^2);
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 2*arg(1)^3-2*arg(1)*arg(2)+arg(1)-1;
            fd_y = -1*arg(1)^2+arg(2);
        end       
    end
end

