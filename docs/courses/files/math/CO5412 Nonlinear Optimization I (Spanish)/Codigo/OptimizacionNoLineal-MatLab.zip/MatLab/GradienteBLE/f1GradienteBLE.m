classdef f1GradienteBLE < GradienteBLE
    % Funcion particular
    %   Implementa la funcion 1 de la tarea 6: 0:5x^tAx, 
    %   donde A = diag(1,2,...,n).
    
    properties
    end
    methods
        function obj = f1GradienteBLE(arg)
              obj = obj@GradienteBLE(arg);
              obj.statfilename = 'f_1GradienteBLE';
              obj.n = arg;
              obj.xmin = zeros(arg,1);              
        end
        function [ret]=f(obj,arg)
            ret = 0;
            for i=1:obj.n
                ret = ret +arg(i)*arg(i)*i;
            end
            ret = 0.5*ret;            
        end
        function [g] = grad(obj,arg)
            g = zeros(obj.n,1);
            for i=1:obj.n
               g(i) = i*arg(i); 
            end            
        end
        function H = hessiano(obj)
            H = zeros(obj.n,obj.n);
            for i=1:obj.n
                for j=1:obj.n
                    if i == j
                        H(i,j) = i;
                    else
                        H(i,j) = 0;
                    end
                end
            end
        end
    end
end

