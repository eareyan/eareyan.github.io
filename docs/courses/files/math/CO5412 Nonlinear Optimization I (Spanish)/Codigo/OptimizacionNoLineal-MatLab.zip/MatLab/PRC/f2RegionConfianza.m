classdef f2RegionConfianza < RegionConfianza
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function [d_x,d_y] = d(obj,arg)
        end
        function obj = f2RegionConfianza(arg)
              obj = obj@RegionConfianza(arg);
              obj.xmin = [1;1];
              obj.statfilename = 'f_1RegionConfianza';
        end
        function [ret]=f(obj,arg)
            ret = 100*(arg(2)-arg(1)*arg(1))^2+(1-arg(1))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = -400*arg(1)*arg(2)+400*arg(1)^3-2+2*arg(1);
            fd_y = 200*arg(2)-200*arg(1)*arg(1);
        end
        function H = hessiano(obj,arg)
            H = [-400*arg(2)+1200*arg(1)^2+2,-400*arg(1);-400*arg(1),200];
        end
    end
end

