clear
clc



f1 = f1GradienteConjugado([]);
xk = zeros(f1.n,1);
for i=1:f1.n
    xk(i) = 0.5;
end
[xf1] = f1.metodogradienteconjugado(xk)