classdef f1BFGS < BFGS
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function obj = f1BFGS(arg)
              obj = obj@BFGS(arg);
              obj.xmin = [0;0];
              obj.statfilename = 'f_1BFGS';
        end
        function [ret]=f(obj,arg)
            ret = 3*arg(1)*arg(1)+ 2*arg(1)*arg(2) + arg(2)^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 6*arg(1)+2*arg(2);
            fd_y = 2*arg(1)+2*arg(2);
        end
    end
end

