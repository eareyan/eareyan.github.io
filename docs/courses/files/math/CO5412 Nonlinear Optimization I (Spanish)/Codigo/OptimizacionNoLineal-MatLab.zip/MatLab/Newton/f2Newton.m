classdef f2Newton < Newton
    % Funcion particular
    %   Implementa la funcion 1 de la tarea: 3x1^2+ 2x1x2 + x2^2
    
    properties
    end
    methods
        function obj = f2Newton(arg)
              obj = obj@Newton(arg);
              obj.xmin = [2;1];
              obj.statfilename = 'f_2Newton';
        end
        function [ret]=f(obj,arg)
            ret = (arg(1)-2)^4+(arg(1)-2*arg(2))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 4*(arg(1)-2)^3+2*(arg(1)-2*arg(2));
            fd_y = -4*(arg(1)-2*arg(2));
        end
        function H = hessiano(obj,arg)
            H = [12*(arg(1)-2)^2+2,-4;-4,8];
        end
    end
end

