classdef f3 < GradienteBLI
    % Funcion particular
    %   Implementa la funcion 3 de la tarea.
    
    properties
    end
    methods
        function obj = f3(arg)
              obj = obj@GradienteBLI(arg);
              obj.xmin = [1;1];
              obj.statfilename = 'f_3';
         end        
        function [ret]=f(obj,arg)
            ret = 100*(arg(2)-arg(1)^2)^2+(1-arg(1))^2;
        end
        function [fd_x,fd_y]=grad_f(obj,arg)
            fd_x = 100*(-4*arg(1)*arg(2)+4*arg(1)^3)-2+2*arg(1);
            fd_y = 100*(2*arg(2)-2*arg(1)^2);
        end       
    end
end

