classdef NewtonModificado < Newton
    properties
    end
    methods
        function obj = NewtonModificado(arg)
            obj = obj@Newton(arg);
        end
        function [d_x,d_y] = d(obj,arg)
            [fd_x,fd_y] = obj.grad_f(arg);
            gradf = [fd_x;fd_y];
            %Obtener el hessiano de la funcion
            H = obj.hessiano(arg);
            autoval = eig(H);
            cantautoval = length(autoval);
            minautoval = bitmax;
            %Determinar el minimo autovalor del hessiano en el punto
            for i=1:cantautoval
                if minautoval > autoval(i)
                    minautoval = autoval(i);
                end
            end
            %Si el minimo autovalor es mayor que cero, la matriz es P.D.
            if minautoval>0
                h = H;
            else
            %Si hay algun autovalor igual o menor que cero, la matriz no es
            %P.D. y se debe ajustar la matriz para convertirla en P.D.
                miu = abs(minautoval)+10^-2;
                h = H + miu*eye(cantautoval);
            end
            d = h \ gradf;
            d_x= -1*d(1);
            d_y= -1*d(2);
        end   
        function [ret]=metodonewtonmodificado(obj,xk)
            parar = false;
            k=0;
            fid = fopen(strcat('stats',obj.statfilename,'.txt'),'w');
            fprintf(fid,'k\tkx\t||xk-xmin||\t||grad_f(xk)||\n');
            
            fid_tex = fopen(strcat('stats',obj.statfilename,'.tex'),'w');
            fprintf(fid_tex,'\\underline{Funcion:} $%s$ \\\\ \nParametros: $\\eta = %f; \\rho = %f; x_0 = (%f;%f)$; $x_*=(%f,%f)$ \\\\ \n',obj.statfilename,obj.eta,obj.ro,xk(1),xk(2),obj.xmin(1),obj.xmin(2));
            fprintf(fid_tex,'\\begin{tabular}{|c|c|c|c|c|}\\hline\n\t$k$&$x_k$&$||x_k-x_*||$&$||grad_f(x_k)||$&$recortes$\\\\ \\hline');
            
            recortes = 0;
            while ~parar
                [g1,g2] = obj.grad_f(xk);
                normagrad = obj.norma([g1;g2]);
                fprintf(fid,'%d\t(%f,%f)\t%f\t%f\t%f\n',k,xk(1),xk(2),obj.norma(xk-obj.xmin),normagrad,recortes);                
                fprintf(fid_tex,'\n\t%d&(%f,%f)&%f&%f&%d\\\\ \\hline',k,xk(1),xk(2),obj.norma(xk-obj.xmin),normagrad,recortes);
                
                if normagrad < 10^-5 %condicion de terminacion del algoritmos
                    parar = true;
                else
                    [d1,d2] = obj.d(xk);
                    d = [d1;d2];
                    %Usando BLI
                    [lambda,recortes] = obj.backtracking(xk);
                    xk = xk + lambda*d;
                end
                k = k+1;
                if(k>1000)
                    parar = true;
                end
            end
            ret = xk;
            fclose(fid);
            
            fprintf(fid_tex,'\n\\end{tabular}\\\\\\\\');            
            fclose(fid_tex);            
        end
    end
end