classdef Base
    properties
        eta = 10^-4;
        ro  = 1/2;        
        statfilename = '';
        xmin;
    end
    methods(Static)
        function [ret] = norma(x)
            ret = sqrt(x(1)*x(1)+x(2)*x(2));
        end
    end
    methods(Abstract)
        [ret] = f(obj,arg)
        [fd_x,fd_y] = grad_f(obj,arg)
        [d_x,d_y] = d(obj,arg)
    end    
    methods
        function obj=Base(args)
        end
        function [lambda,k] = backtracking(obj,xk)
            eta_local = obj.eta;
            ro_local = obj.ro;
            lambda = 1;
            parar = false;
            k=0;
            while ~parar
                [d1,d2] = obj.d(xk);
                d = [d1;d2];
                [g1,g2] = obj.grad_f(xk);
                g = [g1;g2];
                %condicion de armijo
                if(obj.f(xk + lambda * d) > obj.f(xk)+eta_local*lambda*g'*d) 
                    lambda = lambda*ro_local;
                    xk = xk+lambda*d;
                    k=k+1;
                else
                    parar = true;
                end            
            end
        end 
        function S = metododogleg(obj,xc,delta)
            %Definiciones
            [grad_x,grad_y]= obj.grad_f(xc);
            g = [grad_x;grad_y];
            h = obj.hessiano(xc);
            Sn = -1*(h\g);
            %Comienza el metodo dogleg
            if(obj.norma(Sn) < delta)
                S = Sn;
            else
                lambda = (obj.norma(g) *  obj.norma(g)) / ( g'*h*g);
                Scp = -lambda * g;
                if(obj.norma(Scp) > delta)
                    S = (delta* Scp) / obj.norma(Scp);
                else
                    %este polinomio esta calculado para el caso R^2
                    p = [Sn(1)^2-2*Sn(1)*Scp(1)+Scp(1)^2+Sn(2)^2-2*Sn(2)*Scp(2)+Scp(2)^2 2*Sn(1)*Scp(1)-2*Scp(1)^2+2*Sn(2)*Scp(2)-2*Scp(2)^2 Scp(1)^2+Scp(2)^2];
                    raices_p = roots(p);
                    cantraices = length(raices_p);
                    lambda_techo = 0.5;
                    for i=1:cantraices
                        if raices_p(i)>0 && raices_p(i)<1
                            lambda_techo = raices_p(i);
                        end
                    end
                    S = lambda_techo * Sn + (1-lambda_techo) * Scp;
                end
            end
        end        
    end
end