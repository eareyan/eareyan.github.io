<?php
require("statistical_framework.php");
echo "<h1>HW2 EX 2-4</h1>";

//Define probability distribution
$probability_distribution = array(0 => array("0" => (1/3),"1" => (2/3)),
								  1 => array("0" => (3/4),"1" => (1/4)));

echo "<pre>probability_distribution: ";print_r($probability_distribution);echo "</pre>";

//Define the loss function
$loss = array("(0,0)"=>0,"(0,1)"=>10,"(1,0)"=>5,"(1,1)"=>0);
echo "<pre>loss: ";print_r($loss);echo "</pre>";								  

//Set of non-randomized decision rules
$decisions = array(	1 => array("0" => 0,"1" => 0),

					2 => array("0" => 1,"1" => 1),
				
					3 => array("0" => 0,"1" => 1),
					
					4 => array("0" => 1,"1" => 0),
					);

echo "<pre>decisions: ";print_r($decisions);echo "</pre>\n";

//compute risk
$risk_array = compute_decision_risk($probability_distribution,$decisions,$loss);

print_risk($risk_array);

//Bayes decision
$prior_distribution = array(0=>(2/5),1=>(3/5)); //d4
$prior_distribution = array(0=>(3/5),1=>(1/5)); //d1
$prior_distribution = array(0=>(2/3),1=>(1/3)); //d1
$prior_distribution = array(0=>(2/3),1=>(1/3)); //d1
$prior_distribution = array(0=>(0),1=>(1)); //d2
$prior_distribution = array(0=>(1),1=>(0)); //d2
//$prior_distribution = array(0=>(16/19),1=>(3/19)); //d1
//$prior_distribution = array(0=>(2.1/16),1=>((13.9/16))); //d2
//$prior_distribution = array(0=>(3.1/16),1=>((12.9/16))); //d4
//$prior_distribution = array(0=>(3/16),1=>((13/16))); //d4
//$prior_distribution = array(0=>(2/16),1=>((14/16))); //d2
//$prior_distribution = array(0=>(2.6/16),1=>((13.4/16))); //d2
//$prior_distribution = array(0=>(2.6/16),1=>((13.4/16))); //d2


//$prior_distribution = array(0=>(3/19),1=>((16/19))); //d2,d4
//$prior_distribution = array(0=>(3.00001/19),1=>((15.99999/19))); //d4
//$prior_distribution = array(0=>(2.9/19),1=>((16.1/19))); //d2
//$prior_distribution = array(0=>(2.99999/19),1=>((16.00001/19))); //d2
compute_bayes_risk( $decisions,  $probability_distribution, $prior_distribution, $risk_array);