<?php
require("statistical_framework.php");
echo "<h1>HW2 EX 2-2</h1>";

//Define probability distribution
$probability_distribution = array(1 => array("0" => 0,"1" => 1),
								  2 => array("0" => (2/3),"1" => (1/3)));

echo "<pre>probability_distribution: ";print_r($probability_distribution);echo "</pre>";

//Define the loss function
$loss = array("(1,1)"=>0,"(1,2)"=>1,"(2,1)"=>1,"(2,2)"=>0);
echo "<pre>loss: ";print_r($loss);echo "</pre>";								  

//Set of non-randomized decision rules
$decisions = array(	1 => array("0" => 1,"1" => 1),

					2 => array("0" => 2,"1" => 2),
				
					3 => array("0" => 1,"1" => 2),
					
					4 => array("0" => 2,"1" => 1)					
					);

echo "<pre>decisions: ";print_r($decisions);echo "</pre>\n";
//compute risk
$risk_array = compute_decision_risk($probability_distribution,$decisions,$loss);

//Bayes decision
$prior_distribution = array(1=>(2/3),2=>(1/3));
compute_bayes_risk( $decisions,  $probability_distribution, $prior_distribution, $risk_array);