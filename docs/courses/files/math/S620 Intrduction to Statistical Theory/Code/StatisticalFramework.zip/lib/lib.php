<?php


function number_to_latex_fraction($number){
	if($number == 0) return "0";
	if($number == 1) return "1";
	if($number == 3) return "3";
	if($number == 4) return "4";
	if($number == 5) return "5";
	if($number == 10) return "10";
	if($number == 10*(1/3)) return '\frac{10}{3}';
	if($number == (20/3)) return '\frac{20}{3}';
	if($number == (15/4)) return '\frac{15}{4}';
	if($number == 10*(2/3)) return '\frac{20}{3}';
	if($number == (25/10)) return '\frac{25}{10}';
	if($number == (1/2)) return '\frac{1}{2}';
	if($number == (1/4)) return '\frac{1}{4}';
	if($number == (3/4)) return '\frac{3}{4}';
	if($number == (1/6)) return '\frac{1}{6}';
	if($number == (1/16)) return '\frac{1}{16}';
	if($number == (3/16)) return '\frac{3}{16}';
	if($number == (9/16)) return '\frac{9}{16}';
	if($number == (1/3)) return '\frac{1}{3}';
	if($number == (2/3)) return '\frac{2}{3}';
	if($number == (5/6)) return '\frac{5}{6}';
	if($number == (4/9)) return '\frac{4}{9}';
	if($number == (5/9)) return '\frac{5}{9}';
	if($number == (7/9)) return '\frac{7}{9}';
	if($number == (8/9)) return '\frac{8}{9}';
	if($number == (1/9)) return '\frac{1}{9}';
	if($number == (1/8)) return '\frac{1}{8}';
	if($number == (2/9)) return '\frac{2}{9}';
	if($number == (3/8)) return '\frac{3}{8}';
	if($number == (15/8)) return '\frac{15}{8}';
	if($number == (5/8)) return '\frac{5}{8}';
	if($number == (11/18)) return '\frac{11}{18}';
	if($number == (1/3) + (1/18)) return '\frac{7}{18}';
	if($number == (7/18)) return '\frac{7}{18}';
	if($number == (1/2)+(1/3)) return '\frac{5}{6}';
	if($number == 2) return '2';
	if($number == (7/4)) return '\frac{7}{4}';
	if($number == (7/16)) return '\frac{7}{16}';
	if($number == (11/8)) return '\frac{11}{8}';
	if($number == (13/8)) return '\frac{13}{8}';
	if($number == (5/4)) return '\frac{5}{4}';
	if($number == (31/16)) return '\frac{31}{16}';
	if($number == (15/16)) return '\frac{15}{16}';
	if($number == (17/16)) return '\frac{17}{16}';
	if($number == (29/16)) return '\frac{29}{16}';
	if($number == (19/16)) return '\frac{19}{16}';
	if($number == (23/16)) return '\frac{23}{16}';
	if($number == (25/16)) return '\frac{25}{16}';
	if($number == (9/8)) return '\frac{9}{8}';
	if($number == (7/8)) return '\frac{7}{8}';
	if($number == (35/32)) return '\frac{35}{32}';
	if($number == (29/32)) return '\frac{29}{32}';
	if($number == (33/32)) return '\frac{33}{32}';
	if($number == (31/32)) return '\frac{31}{32}';
	if($number == (27/32)) return '\frac{27}{32}';
	if($number == (37/32)) return '\frac{37}{32}';
	if($number == (55/90)) return '\frac{55}{90}';
	
	//if($number > 1) return $number;
	die("did not recognize fraction $number");
}
