<?php
error_reporting(E_ALL);
require("lib/lib.php");

function compute_decision_risk(array $probability_distribution, array $decisions, array $loss){
	//Compute Risk:
	$count = 0;
	$risk_array =  array();
	foreach($decisions as $i=>$d){
		$result = 'd_{'.$i.'} = (';
		//echo "<h1>Decision $i</h1>";
		foreach($probability_distribution as $j=>$distribution){
			//echo "<h2>R($j,d_$i)</h2>";
			$risk = 0;
			$string = "";
			$string2 = "";
			if(($count++)%2 == 1){
				$hline = '\\hline';		
			}else{
				$hline = '';
			}
			foreach($distribution as $pair=>$probability){
				//echo "loss[$pair]";
				//echo "($j,$d[$pair])";
				$string .= 'P_'.$j.$pair.'L('.$j.',d_{'.$i.'}'.$pair.') + ';
				$string2 .= number_to_latex_fraction($probability)."\cdot".$loss["($j,".$d[$pair].")"]." + ";
				$risk += $probability * $loss["($j,".$d[$pair].")"];
			}
			$result .= number_to_latex_fraction($risk) . ',';
			$risk_array[$i][$j] = $risk;
			//echo $string; echo "<br/>";
			//echo $string2;echo "<br/>";
			//echo $risk . "</br>";
			//echo "<br>";
			$string = rtrim($string,' + ');
			$string2 = rtrim($string2,' + ');
		echo '						{\scriptsize $R('.$j.',d_{'.$i.'}) = E_'.$j.'L('.$j.',d_{'.$i.'}) = '.$string.' 
									 = '.$string2.' = '.number_to_latex_fraction($risk).' $}% '."\n".' 						\\\\'."$hline\n";
		}
		$result = rtrim($result,',').'), ';
	}
	echo "<pre>"; print_r($risk_array);echo "</pre>";
	return $risk_array;
}

function compute_bayes_risk(array $decisions, array $probability_distribution, array $prior_distribution, array $risk_array){
	$bayes_risks = array();
	foreach($decisions as $i=>$d){
		$sum = 0;
		foreach($probability_distribution as $j=>$distribution){
			echo "pi_$j"."risk(theta$j,d_$i) [$prior_distribution[$j]][".$risk_array[$i][$j]."]<br>";
			$sum += $prior_distribution[$j] * $risk_array[$i][$j];
		}
		$bayes_risks[$i] = $sum;
	}
	echo "<pre>"; print_r($bayes_risks);echo "</pre>";
	print_r(array_keys($bayes_risks, min($bayes_risks)));	


	foreach($bayes_risks as $decision=>$bayes_risk){
		echo "<br/>".$decision . "--" . number_to_latex_fraction($bayes_risk);
	}
}

function print_risk(array $risk_array){
	foreach($risk_array as $d=>$risks){
		echo "<br>decision $d:(";
		foreach($risks as $i=>$risk){
			echo number_to_latex_fraction($risk).",";
		}
		echo ")";
	}
}
?>