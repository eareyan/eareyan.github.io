<html>
	<head>
		<title>Agregar una pel&iacute;cula</title>
	</head>
	<body>
		<h1>Agregar una pel&iacute;cula</h1>
		<form method="post" action="confirmaragregarpelicula.php">
			Nombre: <input type="text" name="nombre_pelicula"/> <br/>
			A&ntilde;o de Estreno <input type="text" name="fecha_pelicula"/> <br/>
			<input type="submit" value="Enviar"/>
			<input type="reset" value="Reiniciar"/>
		</form>
		<?php include "lib/pie.php"; ?>
	</body>
</html>