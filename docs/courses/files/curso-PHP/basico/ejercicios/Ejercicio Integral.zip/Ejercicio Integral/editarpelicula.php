<html>
	<head>
		<title>Editar una pel&iacute;cula</title>
	</head>
	<body>
		<?php
			require("lib/conexionbd.php");
			//Filtrar el parametro de id_pelicula y evitar SQL Injection
			$id_pelicula = intval($_GET['id_pelicula']);			
			$Query = "SELECT * FROM peliculas WHERE id_pelicula = $id_pelicula";
			$Result = mysqli_query($DB,$Query);
			$NumResults = mysqli_num_rows($Result);
			//Verificar si existe la pel&iacute;
			if($NumResults == 0 ):
		?>
			<h1>No exits la pel&iacute;cula con id <?=$id_pelicula?></h1>
		<?php
			//Si existe
			else:
			$Row = mysqli_fetch_assoc($Result);
		?>
			<form method="post" action="confirmareditarpelicula.php">
				Nombre: <input type="text" name="nombre_pelicula" value="<?=$Row['nombre_pelicula']?>"/> <br/>
				A&ntilde;o de Estreno <input type="text" name="fecha_pelicula" value="<?=$Row['fecha_pelicula']?>"/> <br/>
				<input type="hidden" name="id_pelicula" value="<?=$Row['id_pelicula']?>"/>
				<input type="submit" value="Enviar"/>
				<input type="reset" value="Reiniciar"/>
			</form>
		<?php	
			endif;
			require "lib/pie.php";
		?>
	</body>
</html>