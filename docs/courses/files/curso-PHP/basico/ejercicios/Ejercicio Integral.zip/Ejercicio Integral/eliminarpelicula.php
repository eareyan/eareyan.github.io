<html>
	<head>
		<title>Editar Pelicula</title>
	</head>
	<body>
		<?php
			require("lib/conexionbd.php");
			$Query = 'SELECT * FROM peliculas WHERE id_pelicula = '.$_GET['id_pelicula'];
			$Result = mysqli_query($DB,$Query);
			$NumResults = mysqli_num_rows($Result);
			if($NumResults == 0):
			?>
				<h1>No existe la pelicula</h1>
			<?php 
			else:
				$Row = mysqli_fetch_assoc($Result);
			?>
				<h1>&iquest;Est&aacute; seguro de que desea eliminar la pel&iacute;cula <?=$Row['nombre_pelicula']?>?</h1>
				<form action="confirmareliminarpelicula.php" method="post">
					<input type="hidden" name="id_pelicula" value="<?=$Row['id_pelicula']?>"/>
					<input type="submit" name="eliminar" value="Si, deseo eliminar la pelicula"/>
					<input type="button" name="no eliminar" value="No, deseo regresar al listado de peliculas" onclick="document.location.href = 'listarpeliculas.php'"/>
				</form>
			<?php
			endif;
		?>
	</body>
</html>