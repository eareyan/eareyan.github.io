<html>
	<head>
		<title>Pel&iacute;culas</title>
	</head>
	<body>
		<h1>Colecci&oacute;n de pel&iacute;culas</h1>
	<?php 
		require("lib/conexionbd.php");
		$Query = 'SELECT * FROM peliculas';
		$Result = mysqli_query($DB,$Query);
		$NumResults = mysqli_num_rows($Result);
		?>
		<b><?=$NumResults?> Pel&iacute;culas</b>
		<table border="1">
			<tr>
				<th>Id Pel&iacute;cula</th>
				<th>Nombre</th>
				<th>A&ntilde;o</th>
				<th>Acciones</th>
			</tr>
			<?php while ($Row = mysqli_fetch_assoc($Result)):?>
				<tr>
					<td><?=$Row['id_pelicula']?></td>
					<td><?=$Row['nombre_pelicula']?></td>
					<td><?=$Row['fecha_pelicula']?></td>
					<td>
						<ul>
							<li><a href="editarpelicula.php?id_pelicula=<?=$Row['id_pelicula']?>">Editar</a></li>
							<li><a href="eliminarpelicula.php?id_pelicula=<?=$Row['id_pelicula']?>">Eliminar</a></li>
						</ul>
					</td>
				</tr>
			<?php endwhile;?>
		</table>
		<?php
		mysqli_free_result($Result);
		mysqli_close($DB);
		include "lib/pie.php";
	?>
	</body>
</html>