<html>
	<head>
		<title>Eliminando pelicula</title>
	</head>
		<?php
			//Filtrar el parametro de id_pelicula y evitar SQL Injection
			$id_pelicula = intval($_POST['id_pelicula']);
			//Verificar que el usuario paso por la pantalla de confirmacion de eliminacion
			if(	!isset($_SERVER['HTTP_REFERER']) ||
				$_SERVER['HTTP_REFERER'] != 
				"http://localhost:8888/Ejercicio%20Integral/eliminarpelicula.php?id_pelicula=".$id_pelicula){
				//Si se cumplen las condiciones de arriba, significa que no paso por la pantalla de confirmacion
				die('Estado inv&aacute;lido');	
			}
			//Si llega a esta parte del codigo, significa que si paso por la pantalla de confirmacion de eliminacion
				//Eliminar la pelicula
			require("lib/conexionbd.php");
			$Query = "DELETE FROM peliculas WHERE id_pelicula = $id_pelicula";
			$Result = mysqli_query($DB,$Query);
		?>
		<h1>Se elimino la pelicula exitosamente</h1>
		<a href="listarpeliculas.php">Regresar al listado de pel&iacute;culas</a>
</html>