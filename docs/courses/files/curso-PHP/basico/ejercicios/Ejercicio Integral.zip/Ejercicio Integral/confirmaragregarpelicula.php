<html>
	<head>
		<title>Agregando pelicula</title>
	</head>
		<?php
			//Verificar que el usuario paso por la pantalla de confirmacion de eliminacion
			if(	!isset($_SERVER['HTTP_REFERER']) ||
				$_SERVER['HTTP_REFERER'] != 
				"http://localhost:8888/Ejercicio%20Integral/agregarpelicula.php"){
				//Si se cumplen las condiciones de arriba, significa que no paso por la pantalla de confirmacion
				die('Estado inv&aacute;lido');	
			}
			//Si llega a esta parte del codigo, significa que si paso por la pantalla de confirmacion de eliminacion
				//Eliminar la pelicula
			require("lib/conexionbd.php");
			$Query = "INSERT INTO peliculas SET 
										nombre_pelicula = '".$_POST['nombre_pelicula']."',
										fecha_pelicula = '".$_POST['fecha_pelicula']."'";
			$Result = mysqli_query($DB,$Query);
			if(mysqli_affected_rows($DB) == 1):
		?>
			<h1>Se agreg&oacute; la pel&iacute;cula <?=$_POST['nombre_pelicula']?> exitosamente</h1>
		<?php
			else:
		?>
			<h1>No se agreg&oacute; nada en la base de datos</h1>
		<?php
			endif;
		?>
		<a href="listarpeliculas.php">Ir al listado de pel&iacute;culas</a>
</html>