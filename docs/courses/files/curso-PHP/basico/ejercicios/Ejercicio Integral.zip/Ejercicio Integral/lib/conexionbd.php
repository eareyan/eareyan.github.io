<?php

	@$DB = mysqli_connect('localhost','root','root','cursophpbasico');
	if (mysqli_connect_errno()){
		die("No se pudo conectar con la base de datos:".mysqli_connect_error());
	}