<h3>Opciones</h3>
<ul>
	<li><a href="listarpeliculas.php">Listar pel&iacute;cula</a></li>
	<li><a href="agregarpelicula.php">Agregar pel&iacute;cula</a></li>
	<li><a href="index.php">Regresar al inicio</a></li>
</ul>