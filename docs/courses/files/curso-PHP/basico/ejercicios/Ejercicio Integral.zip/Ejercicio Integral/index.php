<html>
	<head>
		<title>Aplicaci&oacute;n de Pel&iacute;culas</title>
	</head>
	<body>
		<h1>Bienvenido a la aplicaci&oacute;n de pel&iacute;culas</h1>
		<h2>Aqu&iacute; encontrar&aacute;s informaci&oacute;n valiosa sobre tus pel&iacute;culas favoritas</h2>
		<h3>Selecciona una de las siguientes opciones</h3>
		<?php require "lib/pie.php"; ?>
	</body>
</html>