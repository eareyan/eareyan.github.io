<?php

interface Alimento_Interface {
	public function comer($cantidad = 0);
	public function cocinar();
	public function lavar();
}