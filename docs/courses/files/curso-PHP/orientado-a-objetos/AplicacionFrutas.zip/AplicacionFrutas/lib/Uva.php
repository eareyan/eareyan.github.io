<?php

class Uva extends Fruta_Abstract{
	
	public $cantidadDeSemillas;
	
	public function __construct(array $propiedades = null){
		parent::__construct($propiedades);
		if(isset($propiedades['cantidadDeSemillas'])){
			$this->cantidadDeSemillas 	= $propiedades['cantidadDeSemillas'];
		}
	}
	
	public function quitarAlgunasSemillas($cuantas){
		$this->cantidadDeSemillas = $this->cantidadDeSemillas - $cuantas;
	}
	
	public function quitarTodasLasSemillas(){
		self::quitarAlgunasSemillas($this->cantidadDeSemillas);
	}
}
