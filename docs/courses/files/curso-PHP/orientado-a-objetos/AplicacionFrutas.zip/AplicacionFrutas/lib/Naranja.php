<?php

class Naranja extends Fruta_Abstract{



}