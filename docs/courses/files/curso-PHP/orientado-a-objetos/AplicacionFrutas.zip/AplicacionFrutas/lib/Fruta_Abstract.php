<?php

abstract class Fruta_Abstract implements Alimento_Interface{

	/*
	* Propiedades de una fruta cualquiera.
	*/

	protected $color;

	protected $peso;

	protected $tamano;

	protected $textura;

	protected $estaExprimido = false;

	protected $estaSucio = true;

	/*
	* Acciones que se pueden realizar con una fruta cualquiera.
	*/

	public function __construct(array $propiedades = null){
		if(isset($propiedades['color'])){
			$this->color 	= $propiedades['color'];
		}
		if(isset($propiedades['peso'])){
			$this->peso 	= $propiedades['peso'];
		}else{
			//Arrojo una excepcion porque me tiene que definir un peso
			throw new Exception('Para definir una fruta debes darle peso');
		}
		if(isset($propiedades['tamano'])){
			$this->tamano 	= $propiedades['tamano'];
		}
		if(isset($propiedades['textura'])){
			$this->textura 	= $propiedades['textura'];
		}
	}

	//Esta funcion "lava" la fruta
	public function lavar(){
		$this->estaSucio = false;
	}
	//Esta funcion "exprime" la fruta
	public function exprimir(){
		$this->estaExprimido = true;	
	}
	//Cocinar
	public function cocinar(){
		return true;
	}
	//Recibe una cantidad de gramos y los resta del peso.
	//MOSCA, lanza una excepcion si no se recibe un entero mayor que cero
	public function comer($cantidad = 0){
		if(!is_numeric($cantidad) || $cantidad < 0){
			throw new Exception('No puedes comer cantidades negativas de fruta');
		}else{
			$nuevo_peso = $this->peso - $cantidad;
			if($nuevo_peso<0){
				throw new Exception('No puedes comer mas de lo que hay');			
			}else{
				$this->peso = $nuevo_peso;
			}
		}
	}
	
	
	
	
}