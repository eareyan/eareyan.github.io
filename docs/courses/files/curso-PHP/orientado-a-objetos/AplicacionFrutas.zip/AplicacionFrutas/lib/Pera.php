<?php

class Pera extends Fruta_Abstract{

	

}