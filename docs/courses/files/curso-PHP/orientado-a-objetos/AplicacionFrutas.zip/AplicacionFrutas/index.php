<?php

require 'lib/Alimento_Interface.php';
require 'lib/Fruta_Abstract.php';
require 'lib/Uva.php';
require 'lib/Naranja.php';

/*echo "Voy a crear mis frutas....<br/>";


$mi_uva = new Uva(array('color'		=>	'morado',
						'peso'		=>	'xxxx',
						'textura'	=>	'aspera',
						'tamano'	=>	'2x2cms',
						'cantidadDeSemillas'=>10));
						
echo "<pre>";print_r($mi_uva);echo "</pre>";

echo "<h1>Una docena de uvas</h1>";*/
$docena_uvas = array();
//Hacer una docena de uvas
for($i=0;$i<1;$i++){
	$mi_uva = new Uva(array('color'		=>	'morado',
						'peso'		=>	100,
						'textura'	=>	'aspera',
						'tamano'	=>	'2x2cms',
						'cantidadDeSemillas'=>10));
	$docena_uvas[] = $mi_uva;
	//echo "<pre>";print_r($mi_uva);echo "</pre>";
}
echo "<h2>Antes de Comer....</h2>";
echo "<pre>";print_r($docena_uvas);echo "</pre>";

//Este dato llego por formulario
$datos_del_cliente = 500;

try{
	//Comer 5 de la uva 0
	$docena_uvas[0]->comer($datos_del_cliente);
}catch(Exception $e){
	//echo "<pre>"; print_r($e); echo "</pre>";
	echo "<pre style='color:red'>MIra, no puedes comer menos de lo que ya hay!!!!... Este es el error que me dio:
	 ".$e->getMessage()."</pre>";
}

echo "<h2>Despues de Comer....</h2>";
echo "<pre>";print_r($docena_uvas);echo "</pre>";



/*

//Comer 1 de la uva 1 y le voy a quitar 8 semillas
$docena_uvas[1]->comer(1);
$docena_uvas[1]->quitarAlgunasSemillas(8);
//Comer 20 de la uva 2, quitar tdoas las semillas
$docena_uvas[2]->comer(20);
$docena_uvas[2]->quitarTodasLasSemillas();



*/
echo "Finalizo el programa <br/>";